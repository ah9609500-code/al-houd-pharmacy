# Al-Houd Smart Pharmacy (صيدلية الحود الذكية)
## Architecture, Database Schema, and Operations Manual

### 1. System Overview & Architecture
Al-Houd Smart Pharmacy is a native Android application designed specifically for the Iraqi healthcare market. It combines:
- **Mobile-First Owner Administration:** Allows the pharmacy owner (Dr. Ahmed Al-Houd) to modify product prices, promotional discounts, stock availability, and working hours directly from the mobile phone without code redeployment.
- **Modern E-Commerce Store:** Optimized for Arabic (RTL), currency in Iraqi Dinar (IQD), free delivery threshold calculator, coupons, and local Iraqi address handling.
- **Healthcare Social Network:** Verified community feed for official health advice, drug awareness, customer discussions, ratings, and pharmacy moderation.
- **Smart Medicine Requests & Comparison:** Customer requested drug tracking (for scarce/unlisted items) and side-by-side drug comparison.

```
                           +---------------------------+
                           |  Jetpack Compose UI (RTL) |
                           |  - HomeScreen             |
                           |  - CategoriesScreen       |
                           |  - ProductDetailScreen    |
                           |  - CommunityScreen        |
                           |  - CartAndCheckoutScreen  |
                           |  - OrdersScreen           |
                           |  - AdminDashboardScreen   |
                           |  - MedicineRequestScreen  |
                           |  - CompareScreen          |
                           +-------------+-------------+
                                         |
                                         v
                           +---------------------------+
                           |     PharmacyViewModel     |
                           |  (StateFlow / Coroutines) |
                           +-------------+-------------+
                                         |
                                         v
                           +---------------------------+
                           |    PharmacyRepository     |
                           | (Validation, Stock, Logs) |
                           +-------------+-------------+
                                         |
                                         v
                           +---------------------------+
                           |  Room SQLite Persistence  |
                           | - ProductDao              |
                           | - OrderDao                |
                           | - SocialDao               |
                           | - ExtraDao                |
                           +---------------------------+
```

---

### 2. Database Schema (Entities & Relationships)

#### A. `products`
| Column | Type | Description |
|---|---|---|
| `id` | Long (PK auto) | Unique product ID |
| `nameAr` | String | Commercial name in Arabic (e.g. بنادول إكسترا) |
| `nameEn` | String | Commercial name in English (e.g. Panadol Extra) |
| `genericName` | String | Scientific drug name (e.g. Paracetamol + Caffeine) |
| `activeIngredient` | String | Active ingredient & strength (e.g. 500mg / 65mg) |
| `dosageForm` | String | أقراص، كبسولات، شراب، مرهم، بخاخ، إلخ |
| `manufacturer` | String | الشركة المصنعة (e.g. GSK, SDI Samarra, Pfizer) |
| `categoryId` | String | medicines, vitamins, skincare, devices, baby, supplies |
| `priceIqd` | Long | Current price in Iraqi Dinar (IQD) |
| `originalPriceIqd` | Long | Original price before discount (0 if none) |
| `costPriceIqd` | Long | Cost price for gross profit calculation |
| `discountPercent` | Int | Discount percentage |
| `stockQuantity` | Int | Current stock count |
| `minStockAlert` | Int | Low stock alert threshold |
| `batchNumber` | String | Production batch number |
| `expiryDate` | String | Expiry date (e.g. "2027-09") |
| `isAvailable` | Boolean | Availability toggle |
| `requiresPrescription` | Boolean | True if prescription is required by Iraqi law |
| `descriptionAr` | String | Indications and overview |
| `usageInstructions` | String | Dosage and directions |
| `warnings` | String | Safety contraindications and warnings |

#### B. `categories`
| Column | Type | Description |
|---|---|---|
| `id` | String (PK) | Category key |
| `nameAr` | String | Arabic category title |
| `nameEn` | String | English title |
| `iconKey` | String | Material symbol identifier |
| `displayOrder` | Int | Order in category bar |

#### C. `orders` & `order_items`
- `orders`: `id` (e.g. "ALH-1042"), `customerName`, `customerPhone`, `deliveryAddress`, `governorate`, `deliveryType` ("DELIVERY"/"PICKUP"), `status` ("NEW", "AWAITING_CONFIRMATION", "PREPARING", "OUT_FOR_DELIVERY", "COMPLETED", "CANCELLED"), `subtotalIqd`, `discountIqd`, `deliveryFeeIqd`, `totalIqd`, `paymentMethod`, `notes`, `itemsSummary`, `createdAt`.
- `order_items`: `id`, `orderId`, `productId`, `productNameAr`, `unitPriceIqd`, `quantity`, `totalPriceIqd`.

#### D. `social_posts` & `comments`
- `social_posts`: `id`, `authorName`, `isOfficialPharmacy`, `title`, `content`, `categoryTag`, `likesCount`, `commentsCount`, `pinned`, `createdAt`.
- `comments`: `id`, `productId`, `postId`, `userName`, `userRole`, `commentText`, `rating` (1-5), `isVerifiedPurchase`, `replyText`, `replyBy`, `replyTimestamp`, `isReported`, `isHidden`, `createdAt`.

#### E. `medicine_requests`
- `id`, `medicineName`, `customerName`, `customerPhone`, `notes`, `requestCount`, `status` ("PENDING", "ARRIVED"), `requestedAt`, `fulfilledAt`.

#### F. `pharmacy_settings` & `audit_logs`
- Store pharmacy working hours, delivery thresholds, emergency phone, WhatsApp number, owner PIN ("1234"), and audit logs for all price/stock changes.

---

### 3. How to Run & Test
1. In the AI Studio Streaming Android Emulator, the app launches directly.
2. **Owner Access:** Open the **حسابي (My Account)** tab -> Click **تسجيل دخول صاحب الصيدلية** -> Enter PIN: `1234` -> Enter **لوحة تحكم إدارة الصيدلية (Admin Dashboard)**.
3. **Price/Stock Editing:** Under the "الأدوية والأسعار" tab, click "تعديل السعر" on any medicine (e.g. Panadol Extra) and change the price. Switch back to the customer store to verify the instant update.
4. **Ordering:** Add products to the cart -> Proceed to Cart & Checkout -> Use coupon `ALHOUD10` -> Submit order -> View order in "الطلبات" and in Admin Dashboard.

---

### 4. Release APK Generation & Installation
To generate a release APK on your machine:
```bash
gradle assembleRelease
# or for an unsigned/debug APK:
gradle assembleDebug
```
The output APK will be located at:
`app/build/outputs/apk/release/app-release.apk` (or `app-debug.apk`).

To install on your Android phone:
1. Transfer `app-debug.apk` to your phone via USB or WhatsApp/Telegram/Google Drive.
2. On your phone, tap the APK file and allow "Install from Unknown Sources" when prompted.
3. Open "صيدلية الحود الذكية" directly from your home screen.
