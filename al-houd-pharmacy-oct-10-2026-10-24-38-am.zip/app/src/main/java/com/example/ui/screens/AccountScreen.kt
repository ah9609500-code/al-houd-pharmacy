package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.data.repository.PharmacyRepository
import com.example.ui.PharmacyViewModel
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyPrimary

@Composable
fun AccountScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val userRole by viewModel.userRole.collectAsStateWithLifecycle()
    val settings by viewModel.pharmacySettings.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()

    var showPinDialog by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("account_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = null,
                            tint = PharmacyPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (userRole == UserRole.OWNER) (settings?.ownerName ?: "د. أحمد الحود") else "أحمد حيدر (زبون)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (userRole == UserRole.OWNER) "المالك والمدير المسؤول" else "07701234567 • بغداد",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = if (userRole == UserRole.OWNER) PharmacyPrimary else Color(0xFFE0F2FE),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "الدور الحالي: ${userRole.titleAr}",
                                color = if (userRole == UserRole.OWNER) Color.White else Color(0xFF0369A1),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Owner Admin Dashboard Access Banner (Requirements 1 & 7)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (userRole == UserRole.OWNER) {
                            viewModel.navigateTo("admin_dashboard")
                        } else {
                            showPinDialog = true
                        }
                    },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (userRole == UserRole.OWNER) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (userRole == UserRole.OWNER) PharmacyPrimary else Color(0xFFD97706)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (userRole == UserRole.OWNER) Icons.Filled.AdminPanelSettings else Icons.Filled.Lock,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (userRole == UserRole.OWNER) "لوحة تحكم إدارة الصيدلية" else "تسجيل دخول صاحب الصيدلية",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (userRole == UserRole.OWNER) Color(0xFF166534) else Color(0xFF92400E)
                        )
                        Text(
                            text = if (userRole == UserRole.OWNER) "تعديل الأسعار فورياً، إدارة المخزون، والطلبات" else "محمي بكلمة مرور/رمز PIN (الافتراضي: 1234)",
                            fontSize = 11.sp,
                            color = if (userRole == UserRole.OWNER) Color(0xFF166534) else Color(0xFF92400E)
                        )
                    }

                    Icon(
                        imageVector = Icons.Filled.ChevronLeft,
                        contentDescription = null,
                        tint = if (userRole == UserRole.OWNER) PharmacyPrimary else Color(0xFFD97706)
                    )
                }
            }
        }

        // Loyalty & Rewards Program (Feature 14.C)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Stars, contentDescription = null, tint = Color(0xFFEAB308))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("برنامج ولاء ومكافآت الحود", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(6.dp)) {
                            Text("المستوى الفضي", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309), modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("185", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = PharmacyPrimary)
                            Text("نقطة مكتسبة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Divider(modifier = Modifier.height(36.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(PharmacyRepository.formatIqd(9250), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0284C7))
                            Text("قيمة الخصم المتاح", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "اكسب 1 نقطة لكل 1,000 د.ع مشتريات واستبدلها بخصومات على أدويتك ومستلزماتك القادمة.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Quick Shortcuts: Favorites, Compare, Medicine Request
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    AccountNavigationRow(
                        icon = Icons.Filled.Favorite,
                        title = "الأدوية والمستلزمات المفضلة",
                        badge = "${favorites.size}",
                        onClick = {
                            viewModel.setSortFilter("all")
                            viewModel.navigateTo("categories")
                        }
                    )
                    Divider(modifier = Modifier.padding(horizontal = 16.dp))
                    AccountNavigationRow(
                        icon = Icons.Filled.CompareArrows,
                        title = "مقارنة الأدوية والمواد الفعالة",
                        onClick = { viewModel.navigateTo("compare") }
                    )
                    Divider(modifier = Modifier.padding(horizontal = 16.dp))
                    AccountNavigationRow(
                        icon = Icons.Filled.SendToMobile,
                        title = "طلب توفير دواء غير موجود",
                        onClick = { viewModel.navigateTo("medicine_request") }
                    )
                }
            }
        }

        // Pharmacy Info & Contact Details
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "معلومات صيدلية الحود الذكية",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Divider()

                    InfoRow(icon = Icons.Filled.LocationOn, label = "العنوان:", value = settings?.address ?: "بغداد - المنصور - شارع 14 رمضان")
                    InfoRow(icon = Icons.Filled.AccessTime, label = "ساعات العمل:", value = settings?.workingHours ?: "يومياً 8:00 ص - 12:00 م")
                    InfoRow(icon = Icons.Filled.Phone, label = "رقم الهاتف:", value = settings?.phoneNumber ?: "+964 770 123 4567")
                    InfoRow(icon = Icons.Filled.Chat, label = "واتساب الاستشارات:", value = settings?.whatsappNumber ?: "+964 780 123 4567")
                }
            }
        }

        // Role Switcher for Testing (Customer vs Staff vs Owner)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "تبديل الصلاحيات والحسابات (تجربة المستخدمين)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        UserRole.values().forEach { role ->
                            FilterChip(
                                selected = userRole == role,
                                onClick = {
                                    if (role == UserRole.OWNER) {
                                        showPinDialog = true
                                    } else {
                                        viewModel.switchRole(role)
                                    }
                                },
                                label = { Text(role.titleAr, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Owner Login Dialog
    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showPinDialog = false
                pinError = false
                enteredPin = ""
            },
            title = { Text("تسجيل دخول إدارة الصيدلية") },
            text = {
                Column {
                    Text("أدخل رمز PIN السري لصاحب الصيدلية (الرمز الافتراضي: 1234):", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = enteredPin,
                        onValueChange = {
                            enteredPin = it
                            pinError = false
                        },
                        label = { Text("رمز PIN") },
                        isError = pinError,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("رمز PIN غير صحيح. يرجى المحاولة ثانية.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.verifyAndLoginAdmin(
                            pin = enteredPin,
                            onSuccess = {
                                showPinDialog = false
                                enteredPin = ""
                                viewModel.navigateTo("admin_dashboard")
                            },
                            onError = {
                                pinError = true
                            }
                        )
                    }
                ) {
                    Text("دخول")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPinDialog = false
                        pinError = false
                        enteredPin = ""
                    }
                ) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun AccountNavigationRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = PharmacyPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (badge != null) {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(10.dp)) {
                    Text(text = badge, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PharmacyPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
            }
            Icon(imageVector = Icons.Filled.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun InfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = PharmacyPrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}
