package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.data.repository.PharmacyRepository
import com.example.ui.PharmacyViewModel
import com.example.ui.components.PriceDisplay
import com.example.ui.components.StatusBadge
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyBadgeRed
import com.example.ui.theme.PharmacyPrimary

@Composable
fun AdminDashboardScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val allOrders by viewModel.allOrders.collectAsStateWithLifecycle()
    val lowStockProducts by viewModel.lowStockProducts.collectAsStateWithLifecycle()
    val medicineRequests by viewModel.medicineRequests.collectAsStateWithLifecycle()
    val comments by viewModel.allModerationComments.collectAsStateWithLifecycle()
    val settings by viewModel.pharmacySettings.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf("products") } // "products", "orders", "alerts", "requests", "comments", "analytics", "settings"

    // Dialog States
    var productToEditPrice by remember { mutableStateOf<ProductEntity?>(null) }
    var newPriceText by remember { mutableStateOf("") }
    var newOrigPriceText by remember { mutableStateOf("") }
    var newDiscountText by remember { mutableStateOf("") }

    var productToEditStock by remember { mutableStateOf<ProductEntity?>(null) }
    var newStockText by remember { mutableStateOf("") }
    var isAvailableToggle by remember { mutableStateOf(true) }

    var showAddProductDialog by remember { mutableStateOf(false) }
    var showCsvDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Surface(
                color = PharmacyPrimary,
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.navigateTo("account") }) {
                                Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع", tint = Color.White)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "لوحة إدارة صيدلية الحود",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Text(
                                    text = "د. أحمد الحود • تحكم مباشر من الهاتف",
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Surface(
                            color = Color.White.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "المالك / المدير",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dashboard Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "products" to "الأدوية والأسعار (${allProducts.size})",
                            "orders" to "الطلبات (${allOrders.size})",
                            "alerts" to "نواقص المخزون (${lowStockProducts.size})",
                            "requests" to "طلبات الأدوية (${medicineRequests.size})",
                            "comments" to "التعليقات والإشراف (${comments.size})",
                            "analytics" to "المبيعات والأرباح",
                            "settings" to "إعدادات الصيدلية"
                        ).forEach { (id, label) ->
                            FilterChip(
                                selected = selectedTab == id,
                                onClick = { selectedTab = id },
                                label = { Text(label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color.White,
                                    selectedLabelColor = PharmacyPrimary,
                                    containerColor = Color.White.copy(alpha = 0.15f),
                                    labelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (selectedTab == "products") {
                ExtendedFloatingActionButton(
                    onClick = { showAddProductDialog = true },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("إضافة دواء جديد") },
                    containerColor = PharmacyPrimary,
                    contentColor = Color.White
                )
            }
        },
        modifier = modifier.testTag("admin_dashboard_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                // TAB 1: PRODUCT & PRICE MANAGEMENT
                "products" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Surface(
                                color = Color(0xFFE0F2FE),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Info, contentDescription = null, tint = Color(0xFF0369A1), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "تعديل الأسعار والمخزون يتم فورياً دون تعديل الكود البرمجي ويظهر للزبائن لحظياً.",
                                        fontSize = 12.sp,
                                        color = Color(0xFF0369A1)
                                    )
                                }
                            }
                        }

                        items(allProducts) { product ->
                            AdminProductRow(
                                product = product,
                                onEditPrice = {
                                    productToEditPrice = product
                                    newPriceText = product.priceIqd.toString()
                                    newOrigPriceText = product.originalPriceIqd.toString()
                                    newDiscountText = product.discountPercent.toString()
                                },
                                onEditStock = {
                                    productToEditStock = product
                                    newStockText = product.stockQuantity.toString()
                                    isAvailableToggle = product.isAvailable
                                },
                                onDelete = { viewModel.deleteProduct(product) }
                            )
                        }
                    }
                }

                // TAB 2: ORDERS MANAGEMENT
                "orders" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(allOrders) { order ->
                            AdminOrderCard(
                                order = order,
                                onStatusChange = { newStatus ->
                                    viewModel.updateOrderStatus(order.id, newStatus)
                                }
                            )
                        }
                    }
                }

                // TAB 3: STOCK & EXPIRY ALERTS
                "alerts" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "تنبيهات انخفاض المخزون وقرب انتهاء الصلاحية",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        if (lowStockProducts.isEmpty()) {
                            item {
                                Text(
                                    text = "جميع الأدوية والمستلزمات متوفرة بكميات كافية ولا يوجد عجز مخزني حالياً.",
                                    fontSize = 13.sp,
                                    color = PharmacyBadgeGreen
                                )
                            }
                        }

                        items(lowStockProducts) { product ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = product.nameAr, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(text = "المتبقي: ${product.stockQuantity} فقط (الحد الأدنى: ${product.minStockAlert})", color = Color(0xFFB45309), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(text = "تاريخ الصلاحية: ${product.expiryDate} • تشغيلة: ${product.batchNumber}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Button(
                                        onClick = {
                                            productToEditStock = product
                                            newStockText = "50"
                                            isAvailableToggle = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                                    ) {
                                        Text("إعادة تزويد")
                                    }
                                }
                            }
                        }
                    }
                }

                // TAB 4: MEDICINE REQUESTS (Feature 14.A)
                "requests" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "طلبات الأدوية غير المتوفرة من الزبائن (دراسة الاحتياج)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        items(medicineRequests) { req ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = req.medicineName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Surface(
                                            color = if (req.status == "ARRIVED") Color(0xFFDCFCE7) else Color(0xFFFEF3C7),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = if (req.status == "ARRIVED") "تم التوفير بالصيدلية" else "قيد البحث والتوفير",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (req.status == "ARRIVED") Color(0xFF15803D) else Color(0xFFB45309),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "الزبون: ${req.customerName} (${req.customerPhone})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    if (req.notes.isNotBlank()) {
                                        Text(text = "ملاحظات: ${req.notes}", fontSize = 11.sp)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    if (req.status == "PENDING") {
                                        Button(
                                            onClick = { viewModel.markMedicineRequestStatus(req.id, "ARRIVED") },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("تم توفير الدواء (إشعار الزبون)")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // TAB 5: COMMUNITY MODERATION (Feature 4)
                "comments" -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "الإشراف على تعليقات واستفسارات الزبائن",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        items(comments) { comment ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "${comment.userName} (${comment.userRole})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        if (comment.isReported) {
                                            Surface(color = Color(0xFFFFE4E6), shape = RoundedCornerShape(4.dp)) {
                                                Text("مبلغ عنه", color = Color.Red, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = comment.commentText, fontSize = 12.sp)

                                    if (comment.replyText != null) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = "الرد الحالي: ${comment.replyText}", fontSize = 11.sp, color = PharmacyPrimary)
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        TextButton(onClick = { viewModel.deleteComment(comment.id) }) {
                                            Text("حذف", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // TAB 6: BUSINESS ANALYTICS & PROFIT REPORTS (Feature 14.H)
                "analytics" -> {
                    val completedOrders = allOrders.filter { it.status == "COMPLETED" }
                    val totalRevenue = completedOrders.sumOf { it.totalIqd }
                    val estimatedGrossProfit = (totalRevenue * 0.28).toLong() // 28% estimated pharmacy margin

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "التقارير المالية وإحصائيات المبيعات",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Button(
                                    onClick = { showCsvDialog = true },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تصدير CSV")
                                }
                            }
                        }

                        // Summary Cards Grid
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AnalyticsMetricCard(
                                    title = "إجمالي المبيعات المكتملة",
                                    value = PharmacyRepository.formatIqd(totalRevenue),
                                    icon = Icons.Filled.Payments,
                                    color = PharmacyPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                AnalyticsMetricCard(
                                    title = "إجمالي الأرباح المقدرة",
                                    value = PharmacyRepository.formatIqd(estimatedGrossProfit),
                                    icon = Icons.Filled.TrendingUp,
                                    color = Color(0xFF0284C7),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AnalyticsMetricCard(
                                    title = "عدد الطلبات المكتملة",
                                    value = "${completedOrders.size} طلب",
                                    icon = Icons.Filled.CheckCircle,
                                    color = PharmacyBadgeGreen,
                                    modifier = Modifier.weight(1f)
                                )
                                AnalyticsMetricCard(
                                    title = "متوسط قيمة الطلب",
                                    value = if (completedOrders.isNotEmpty()) PharmacyRepository.formatIqd(totalRevenue / completedOrders.size) else "0 د.ع",
                                    icon = Icons.Filled.Receipt,
                                    color = Color(0xFFD97706),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        // Audit Log List
                        item {
                            Text(
                                text = "سجل العمليات والتدقيق الإداري (Audit Log)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        items(auditLogs.take(15)) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = log.actionType, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PharmacyPrimary)
                                        Text(text = log.performedBy, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = log.details, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // TAB 7: PHARMACY SETTINGS
                "settings" -> {
                    settings?.let { s ->
                        var nameAr by remember(s) { mutableStateOf(s.pharmacyNameAr) }
                        var ownerName by remember(s) { mutableStateOf(s.ownerName) }
                        var phone by remember(s) { mutableStateOf(s.phoneNumber) }
                        var whatsapp by remember(s) { mutableStateOf(s.whatsappNumber) }
                        var address by remember(s) { mutableStateOf(s.address) }
                        var workingHours by remember(s) { mutableStateOf(s.workingHours) }
                        var deliveryFee by remember(s) { mutableStateOf(s.deliveryFeeIqd.toString()) }
                        var freeDeliveryThreshold by remember(s) { mutableStateOf(s.freeDeliveryThresholdIqd.toString()) }
                        var adminPin by remember(s) { mutableStateOf(s.adminPin) }

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Text(text = "تعديل بيانات وإعدادات صيدلية الحود الذكية", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }

                            item {
                                OutlinedTextField(
                                    value = nameAr,
                                    onValueChange = { nameAr = it },
                                    label = { Text("اسم الصيدلية") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = ownerName,
                                    onValueChange = { ownerName = it },
                                    label = { Text("اسم الصيدلي المسؤول / المالك") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = phone,
                                    onValueChange = { phone = it },
                                    label = { Text("رقم هاتف الصيدلية") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = whatsapp,
                                    onValueChange = { whatsapp = it },
                                    label = { Text("رقم واتساب الاستشارات") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = address,
                                    onValueChange = { address = it },
                                    label = { Text("عنوان الفرع") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = workingHours,
                                    onValueChange = { workingHours = it },
                                    label = { Text("ساعات الدوام والعمل") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = deliveryFee,
                                    onValueChange = { deliveryFee = it },
                                    label = { Text("أجور التوصيل (د.ع)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = freeDeliveryThreshold,
                                    onValueChange = { freeDeliveryThreshold = it },
                                    label = { Text("حد التوصيل المجاني (د.ع)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = adminPin,
                                    onValueChange = { adminPin = it },
                                    label = { Text("رمز PIN السري لصاحب الصيدلية") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            item {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        viewModel.updatePharmacySettings(
                                            s.copy(
                                                pharmacyNameAr = nameAr,
                                                ownerName = ownerName,
                                                phoneNumber = phone,
                                                whatsappNumber = whatsapp,
                                                address = address,
                                                workingHours = workingHours,
                                                deliveryFeeIqd = deliveryFee.toLongOrNull() ?: 3000L,
                                                freeDeliveryThresholdIqd = freeDeliveryThreshold.toLongOrNull() ?: 35000L,
                                                adminPin = adminPin.ifBlank { "1234" }
                                            )
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Text("حفظ التعديلات")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Quick Price Editor Dialog
    productToEditPrice?.let { prod ->
        AlertDialog(
            onDismissRequest = { productToEditPrice = null },
            title = { Text("تعديل سعر: ${prod.nameAr}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPriceText,
                        onValueChange = { newPriceText = it },
                        label = { Text("السعر الحالي الجديد (د.ع)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newOrigPriceText,
                        onValueChange = { newOrigPriceText = it },
                        label = { Text("السعر الأصلي قبل الخصم (0 إذا لا يوجد)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newDiscountText,
                        onValueChange = { newDiscountText = it },
                        label = { Text("نسبة الخصم %") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = newPriceText.toLongOrNull() ?: prod.priceIqd
                        val orig = newOrigPriceText.toLongOrNull() ?: 0L
                        val disc = newDiscountText.toIntOrNull() ?: 0
                        viewModel.quickUpdatePrice(prod.id, p, orig, disc)
                        productToEditPrice = null
                    }
                ) {
                    Text("حفظ وتحديث السعر")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToEditPrice = null }) { Text("إلغاء") }
            }
        )
    }

    // Quick Stock Editor Dialog
    productToEditStock?.let { prod ->
        AlertDialog(
            onDismissRequest = { productToEditStock = null },
            title = { Text("تعديل مخزون: ${prod.nameAr}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newStockText,
                        onValueChange = { newStockText = it },
                        label = { Text("الكمية المتوفرة بالمخزن") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("الحالة: ${if (isAvailableToggle) "متوفر للبيع" else "غير متوفر"}")
                        Switch(
                            checked = isAvailableToggle,
                            onCheckedChange = { isAvailableToggle = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val stock = newStockText.toIntOrNull() ?: prod.stockQuantity
                        viewModel.quickUpdateStock(prod.id, stock, isAvailableToggle && stock > 0)
                        productToEditStock = null
                    }
                ) {
                    Text("تحديث المخزون")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToEditStock = null }) { Text("إلغاء") }
            }
        )
    }

    // Add New Product Dialog
    if (showAddProductDialog) {
        var nameAr by remember { mutableStateOf("") }
        var nameEn by remember { mutableStateOf("") }
        var genericName by remember { mutableStateOf("") }
        var activeIngredient by remember { mutableStateOf("") }
        var strength by remember { mutableStateOf("") }
        var dosageForm by remember { mutableStateOf("أقراص") }
        var manufacturer by remember { mutableStateOf("شركة أدوية معتمدة") }
        var catId by remember { mutableStateOf("medicines") }
        var price by remember { mutableStateOf("5000") }
        var cost by remember { mutableStateOf("3500") }
        var stock by remember { mutableStateOf("30") }
        var requiresPrescription by remember { mutableStateOf(false) }
        var desc by remember { mutableStateOf("علاج طبي فعال وفق إرشادات الطبيب والصيدلي.") }
        var usage by remember { mutableStateOf("قرص مرتين يومياً بعد الطعام.") }
        var warnings by remember { mutableStateOf("يحفظ بعيداً عن متناول الأطفال.") }

        AlertDialog(
            onDismissRequest = { showAddProductDialog = false },
            title = { Text("إضافة دواء جديد للكتالوج") },
            text = {
                LazyColumn(
                    modifier = Modifier.height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = nameAr,
                            onValueChange = { nameAr = it },
                            label = { Text("الاسم التجاري (عربي)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = nameEn,
                            onValueChange = { nameEn = it },
                            label = { Text("الاسم بالإنجليزية") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = genericName,
                            onValueChange = { genericName = it },
                            label = { Text("الاسم العلمي (Generic)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = activeIngredient,
                            onValueChange = { activeIngredient = it },
                            label = { Text("المادة الفعالة والتركيز") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = price,
                                onValueChange = { price = it },
                                label = { Text("السعر للزبون (د.ع)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = cost,
                                onValueChange = { cost = it },
                                label = { Text("سعر التكلفة (د.ع)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = stock,
                            onValueChange = { stock = it },
                            label = { Text("الكمية بالمخزن") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("يحتاج وصفة طبية؟")
                            Switch(checked = requiresPrescription, onCheckedChange = { requiresPrescription = it })
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameAr.isNotBlank()) {
                            val newProd = ProductEntity(
                                nameAr = nameAr,
                                nameEn = nameEn.ifBlank { nameAr },
                                genericName = genericName.ifBlank { nameAr },
                                activeIngredient = activeIngredient.ifBlank { nameAr },
                                strength = strength.ifBlank { "قياسي" },
                                dosageForm = dosageForm,
                                manufacturer = manufacturer,
                                categoryId = catId,
                                priceIqd = price.toLongOrNull() ?: 5000L,
                                costPriceIqd = cost.toLongOrNull() ?: 3500L,
                                stockQuantity = stock.toIntOrNull() ?: 20,
                                isAvailable = true,
                                requiresPrescription = requiresPrescription,
                                descriptionAr = desc,
                                usageInstructions = usage,
                                warnings = warnings
                            )
                            viewModel.saveProduct(newProd) {
                                showAddProductDialog = false
                            }
                        }
                    },
                    enabled = nameAr.isNotBlank()
                ) {
                    Text("حفظ وإضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddProductDialog = false }) { Text("إلغاء") }
            }
        )
    }

    // CSV Export Preview Dialog
    if (showCsvDialog) {
        val completed = allOrders.filter { it.status == "COMPLETED" }
        val csvPreview = buildString {
            append("رقم الطلب,الزبون,الهاتف,المجموع (د.ع),التاريخ,الحالة\n")
            completed.forEach {
                append("${it.id},${it.customerName},${it.customerPhone},${it.totalIqd},${it.createdAt},${it.status}\n")
            }
        }
        AlertDialog(
            onDismissRequest = { showCsvDialog = false },
            title = { Text("تصدير تقرير المبيعات (CSV)") },
            text = {
                Column {
                    Text("تم تجهيز التقرير بصيغة CSV المتوافقة مع Microsoft Excel وجداول البيانات:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    ) {
                        Text(
                            text = csvPreview,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showCsvDialog = false
                    viewModel.showSnackbar("تم تصدير التقرير المالي بنجاح!")
                }) {
                    Text("تأكيد التصدير")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCsvDialog = false }) { Text("إغلاق") }
            }
        )
    }
}

@Composable
fun AdminProductRow(
    product: ProductEntity,
    onEditPrice: () -> Unit,
    onEditStock: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = product.nameAr, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "${product.dosageForm} • ${product.genericName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatusBadge(status = if (product.stockQuantity <= 0) "OUT_OF_STOCK" else if (product.stockQuantity <= product.minStockAlert) "LOW_STOCK" else "IN_STOCK")
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "السعر الحالي: ${PharmacyRepository.formatIqd(product.priceIqd)}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = PharmacyPrimary)
                    Text(text = "المخزون: ${product.stockQuantity} قطعة", fontSize = 11.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(
                        onClick = onEditPrice,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("تعديل السعر", fontSize = 11.sp)
                    }
                    FilledTonalButton(
                        onClick = onEditStock,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("المخزون", fontSize = 11.sp)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminOrderCard(
    order: OrderEntity,
    onStatusChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "طلب #${order.id}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                StatusBadge(status = order.status)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "الزبون: ${order.customerName} - ${order.customerPhone}", fontSize = 12.sp)
            Text(text = "العنوان: ${order.deliveryAddress}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = "الأصناف: ${order.itemsSummary}", fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(text = "المجموع: ${PharmacyRepository.formatIqd(order.totalIqd)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PharmacyPrimary)

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "تحديث حالة الطلب:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "NEW" to "جديد",
                    "AWAITING_CONFIRMATION" to "تأكيد",
                    "PREPARING" to "تجهيز",
                    "OUT_FOR_DELIVERY" to "توصيل",
                    "COMPLETED" to "اكتمل",
                    "CANCELLED" to "إلغاء"
                ).forEach { (st, label) ->
                    AssistChip(
                        onClick = { onStatusChange(st) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (order.status == st) PharmacyPrimary else MaterialTheme.colorScheme.surfaceVariant,
                            labelColor = if (order.status == st) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AnalyticsMetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = color)
        }
    }
}
