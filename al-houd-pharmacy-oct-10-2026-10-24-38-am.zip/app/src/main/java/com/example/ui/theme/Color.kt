package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Medical Theme
val PharmacyPrimary = Color(0xFF0D6B42)
val PharmacyOnPrimary = Color(0xFFFFFFFF)
val PharmacyPrimaryContainer = Color(0xFFDCFCE7)
val PharmacyOnPrimaryContainer = Color(0xFF023E23)

val PharmacySecondary = Color(0xFF0284C7)
val PharmacyOnSecondary = Color(0xFFFFFFFF)
val PharmacySecondaryContainer = Color(0xFFE0F2FE)
val PharmacyOnSecondaryContainer = Color(0xFF03466B)

val PharmacyTertiary = Color(0xFFE11D48)
val PharmacyOnTertiary = Color(0xFFFFFFFF)
val PharmacyTertiaryContainer = Color(0xFFFFE4E6)
val PharmacyOnTertiaryContainer = Color(0xFF4C0519)

val PharmacyBackground = Color(0xFFF8FAFC)
val PharmacyOnBackground = Color(0xFF0F172A)
val PharmacySurface = Color(0xFFFFFFFF)
val PharmacyOnSurface = Color(0xFF0F172A)
val PharmacySurfaceVariant = Color(0xFFF1F5F9)
val PharmacyOnSurfaceVariant = Color(0xFF475569)
val PharmacyOutline = Color(0xFFCBD5E1)
val PharmacyOutlineVariant = Color(0xFFE2E8F0)

// Dark Medical Theme
val PharmacyPrimaryDark = Color(0xFF4ADE80)
val PharmacyOnPrimaryDark = Color(0xFF00391C)
val PharmacyPrimaryContainerDark = Color(0xFF00532B)
val PharmacyOnPrimaryContainerDark = Color(0xFF86EFAC)

val PharmacySecondaryDark = Color(0xFF38BDF8)
val PharmacyOnSecondaryDark = Color(0xFF00344F)
val PharmacySecondaryContainerDark = Color(0xFF004D73)
val PharmacyOnSecondaryContainerDark = Color(0xFFBAE6FD)

val PharmacyTertiaryDark = Color(0xFFFB7185)
val PharmacyOnTertiaryDark = Color(0xFF4C0519)
val PharmacyTertiaryContainerDark = Color(0xFF70122B)
val PharmacyOnTertiaryContainerDark = Color(0xFFFECDD3)

val PharmacyBackgroundDark = Color(0xFF0B1319)
val PharmacyOnBackgroundDark = Color(0xFFF1F5F9)
val PharmacySurfaceDark = Color(0xFF131D24)
val PharmacyOnSurfaceDark = Color(0xFFF1F5F9)
val PharmacySurfaceVariantDark = Color(0xFF1E293B)
val PharmacyOnSurfaceVariantDark = Color(0xFF94A3B8)
val PharmacyOutlineDark = Color(0xFF334155)
val PharmacyOutlineVariantDark = Color(0xFF1E293B)

// Brand Accents
val PharmacyMint = Color(0xFF10B981)
val PharmacyAmber = Color(0xFFF59E0B)
val PharmacyBadgeRed = Color(0xFFEF4444)
val PharmacyBadgeGreen = Color(0xFF22C55E)
