package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.data.repository.PharmacyRepository
import com.example.ui.theme.*

@Composable
fun PriceDisplay(
    priceIqd: Long,
    originalPriceIqd: Long = 0,
    modifier: Modifier = Modifier,
    large: Boolean = false
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = PharmacyRepository.formatIqd(priceIqd),
            fontWeight = FontWeight.Bold,
            fontSize = if (large) 20.sp else 15.sp,
            color = MaterialTheme.colorScheme.primary
        )
        if (originalPriceIqd > priceIqd) {
            Text(
                text = PharmacyRepository.formatIqd(originalPriceIqd),
                fontSize = if (large) 14.sp else 11.sp,
                textDecoration = TextDecoration.LineThrough,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, textAr) = when (status) {
        "NEW" -> Triple(Color(0xFFE0F2FE), Color(0xFF0369A1), "طلب جديد")
        "AWAITING_CONFIRMATION" -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), "قيد التأكيد")
        "PREPARING" -> Triple(Color(0xFFFDE68A), Color(0xFF92400E), "قيد التجهيز")
        "OUT_FOR_DELIVERY" -> Triple(Color(0xFFEDE9FE), Color(0xFF6D28D9), "في الطريق للتوصيل")
        "COMPLETED" -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), "مكتمل ومستلم")
        "CANCELLED" -> Triple(Color(0xFFFFE4E6), Color(0xFFBE123C), "ملغي")
        "LOW_STOCK" -> Triple(Color(0xFFFFEDD5), Color(0xFFC2410C), "مخزون منخفض")
        "OUT_OF_STOCK" -> Triple(Color(0xFFFFE4E6), Color(0xFFBE123C), "غير متوفر")
        "IN_STOCK" -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), "متوفر بالمخزن")
        else -> Triple(Color(0xFFF1F5F9), Color(0xFF475569), status)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = textAr,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ProductCard(
    product: ProductEntity,
    isFavorite: Boolean,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onProductClick)
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header: Badges & Favorite Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (product.discountPercent > 0) {
                        Surface(
                            color = PharmacyBadgeRed,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "-${product.discountPercent}%",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (product.requiresPrescription) {
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "وصفة طبية",
                                color = Color(0xFF1D4ED8),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "المفضلة",
                        tint = if (isFavorite) PharmacyBadgeRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Visual Medical Icon Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (product.iconKey) {
                    "medication" -> Icons.Filled.Medication
                    "vaccines" -> Icons.Filled.Vaccines
                    "fitness_center" -> Icons.Filled.FitnessCenter
                    "face" -> Icons.Filled.Face
                    "monitor_heart" -> Icons.Filled.MonitorHeart
                    "child_care" -> Icons.Filled.ChildCare
                    "healing" -> Icons.Filled.Healing
                    else -> Icons.Filled.LocalPharmacy
                }
                Icon(
                    imageVector = icon,
                    contentDescription = product.nameAr,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dosage form & Manufacturer tag
            Text(
                text = "${product.dosageForm} • ${product.manufacturer}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            // Commercial Name (Arabic)
            Text(
                text = product.nameAr,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            // Generic Name
            Text(
                text = product.genericName,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Price & Add to Cart
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PriceDisplay(
                    priceIqd = product.priceIqd,
                    originalPriceIqd = product.originalPriceIqd
                )

                FilledTonalIconButton(
                    onClick = onAddToCart,
                    enabled = product.isAvailable && product.stockQuantity > 0,
                    modifier = Modifier.size(36.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddShoppingCart,
                        contentDescription = "إضافة للسلة",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
