package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.PharmacyRepository
import com.example.ui.PharmacyViewModel
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyPrimary

@Composable
fun CompareScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val comparisonList by viewModel.comparisonList.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("compare_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع")
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = "مقارنة الأدوية والمستلزمات",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
                Text(
                    text = "مقارنة المادة الفعالة، الشركة المصنعة، والأسعار",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (comparisonList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.CompareArrows,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لا توجد أدوية مضافة للمقارنة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "اختر دواءين من صفحة التفاصيل لمقارنة الخصائص والأسعار جنباً إلى جنب",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.navigateTo("categories") }) {
                        Text("تصفح الأدوية")
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    Text(
                        text = "الأدوية المحددة للمقارنة (${comparisonList.size} من 2):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                // Comparison Table / Cards
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        comparisonList.forEach { prod ->
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = prod.nameAr,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(
                                            onClick = { viewModel.removeFromCompare(prod.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Filled.Close, contentDescription = "إزالة", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Divider()
                                    CompareAttribute(title = "السعر:", value = PharmacyRepository.formatIqd(prod.priceIqd), highlight = true)
                                    CompareAttribute(title = "الاسم العلمي:", value = prod.genericName)
                                    CompareAttribute(title = "المادة الفعالة:", value = prod.activeIngredient)
                                    CompareAttribute(title = "الشكل والتركيز:", value = "${prod.dosageForm} • ${prod.strength}")
                                    CompareAttribute(title = "الشركة المصنعة:", value = prod.manufacturer)
                                    CompareAttribute(title = "المخزون:", value = if (prod.stockQuantity > 0) "${prod.stockQuantity} متوفرة" else "غير متوفر")
                                    CompareAttribute(title = "وصفة طبية؟", value = if (prod.requiresPrescription) "نعم مطلوبة" else "بدون وصفة")

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Button(
                                        onClick = { viewModel.addToCart(prod) },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("إضافة للسلة", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompareAttribute(
    title: String,
    value: String,
    highlight: Boolean = false
) {
    Column {
        Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.SemiBold,
            color = if (highlight) PharmacyPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}
