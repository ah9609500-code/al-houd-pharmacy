package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.PharmacyDatabase
import com.example.data.model.*
import com.example.data.repository.PharmacyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PharmacyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = PharmacyDatabase.getDatabase(application, viewModelScope)
    val repository = PharmacyRepository(
        database.productDao(),
        database.orderDao(),
        database.socialDao(),
        database.extraDao()
    )

    // Navigation & Screen Stack
    private val _currentScreen = MutableStateFlow("home")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf<String>()

    fun navigateTo(screen: String) {
        if (_currentScreen.value != screen) {
            screenBackStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.isNotEmpty()) {
            _currentScreen.value = screenBackStack.removeAt(screenBackStack.size - 1)
            return true
        } else if (_currentScreen.value != "home") {
            _currentScreen.value = "home"
            return true
        }
        return false
    }

    // Selected Product for Details
    private val _selectedProduct = MutableStateFlow<ProductEntity?>(null)
    val selectedProduct: StateFlow<ProductEntity?> = _selectedProduct.asStateFlow()

    fun selectProduct(product: ProductEntity) {
        _selectedProduct.value = product
        navigateTo("product_detail")
    }

    // Product Comparison
    private val _comparisonList = MutableStateFlow<List<ProductEntity>>(emptyList())
    val comparisonList: StateFlow<List<ProductEntity>> = _comparisonList.asStateFlow()

    fun addToCompare(product: ProductEntity) {
        val current = _comparisonList.value.toMutableList()
        if (current.any { it.id == product.id }) {
            showSnackbar("المنتج مضاف مسبقاً للمقارنة")
            return
        }
        if (current.size >= 2) {
            current.removeAt(0)
        }
        current.add(product)
        _comparisonList.value = current
        showSnackbar("تمت إضافة ${product.nameAr} للمقارنة")
        navigateTo("compare")
    }

    fun removeFromCompare(productId: Long) {
        _comparisonList.value = _comparisonList.value.filter { it.id != productId }
    }

    // Search and Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private val _selectedCategoryFilter = MutableStateFlow<String?>(null)
    val selectedCategoryFilter: StateFlow<String?> = _selectedCategoryFilter.asStateFlow()

    fun setCategoryFilter(categoryId: String?) {
        _selectedCategoryFilter.value = categoryId
    }

    private val _activeSortFilter = MutableStateFlow("all") // all, discount, featured, in_stock, price_asc, price_desc
    val activeSortFilter: StateFlow<String> = _activeSortFilter.asStateFlow()

    fun setSortFilter(filter: String) {
        _activeSortFilter.value = filter
    }

    // Reactive Data Sources
    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<CategoryEntity>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featuredProducts: StateFlow<List<ProductEntity>> = repository.featuredProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val discountedProducts: StateFlow<List<ProductEntity>> = repository.discountedProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bestSellerProducts: StateFlow<List<ProductEntity>> = repository.bestSellerProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<ProductEntity>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPosts: StateFlow<List<SocialPostEntity>> = repository.allPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pharmacySettings: StateFlow<PharmacySettingsEntity?> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val medicineRequests: StateFlow<List<MedicineRequestEntity>> = repository.medicineRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allModerationComments: StateFlow<List<CommentEntity>> = repository.allCommentsForModeration
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Products for Catalog & Search
    val filteredProducts: StateFlow<List<ProductEntity>> = combine(
        allProducts,
        searchQuery,
        selectedCategoryFilter,
        activeSortFilter
    ) { products, query, catId, sort ->
        var list = products

        if (catId != null) {
            list = list.filter { it.categoryId == catId }
        }

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.nameAr.lowercase().contains(q) ||
                it.nameEn.lowercase().contains(q) ||
                it.genericName.lowercase().contains(q) ||
                it.activeIngredient.lowercase().contains(q) ||
                it.manufacturer.lowercase().contains(q)
            }
        }

        when (sort) {
            "discount" -> list.filter { it.discountPercent > 0 }.sortedByDescending { it.discountPercent }
            "featured" -> list.filter { it.isFeatured }
            "in_stock" -> list.filter { it.isAvailable && it.stockQuantity > 0 }
            "price_asc" -> list.sortedBy { it.priceIqd }
            "price_desc" -> list.sortedByDescending { it.priceIqd }
            else -> list
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Shopping Cart
    private val _cart = MutableStateFlow<Map<Long, CartItem>>(emptyMap())
    val cart: StateFlow<Map<Long, CartItem>> = _cart.asStateFlow()

    val cartItemCount: StateFlow<Int> = _cart.map { map ->
        map.values.sumOf { it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val cartSubtotal: StateFlow<Long> = _cart.map { map ->
        map.values.sumOf { it.product.priceIqd * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    private val _appliedCoupon = MutableStateFlow<CouponEntity?>(null)
    val appliedCoupon: StateFlow<CouponEntity?> = _appliedCoupon.asStateFlow()

    fun addToCart(product: ProductEntity, quantity: Int = 1) {
        if (!product.isAvailable || product.stockQuantity <= 0) {
            showSnackbar("عذراً، هذا المنتج غير متوفر بالمخزون حالياً")
            return
        }

        val current = _cart.value.toMutableMap()
        val existing = current[product.id]
        val newQty = (existing?.quantity ?: 0) + quantity

        if (newQty > product.stockQuantity) {
            showSnackbar("الكمية المتاحة في المخزن هي ${product.stockQuantity} فقط")
            return
        }

        current[product.id] = CartItem(product, newQty)
        _cart.value = current
        showSnackbar("تمت إضافة ${product.nameAr} إلى السلة")
    }

    fun updateCartQuantity(productId: Long, delta: Int) {
        val current = _cart.value.toMutableMap()
        val item = current[productId] ?: return
        val newQty = item.quantity + delta
        if (newQty <= 0) {
            current.remove(productId)
        } else {
            if (newQty > item.product.stockQuantity) {
                showSnackbar("أقصى كمية متوفرة في المخزن هي ${item.product.stockQuantity}")
                return
            }
            current[productId] = item.copy(quantity = newQty)
        }
        _cart.value = current
    }

    fun removeFromCart(productId: Long) {
        val current = _cart.value.toMutableMap()
        current.remove(productId)
        _cart.value = current
    }

    fun clearCart() {
        _cart.value = emptyMap()
        _appliedCoupon.value = null
    }

    fun applyCoupon(code: String) {
        viewModelScope.launch {
            val coupon = repository.validateCoupon(code)
            if (coupon != null) {
                if (cartSubtotal.value < coupon.minOrderIqd) {
                    showSnackbar("الحد الأدنى للطلب لتفعيل هذا الكوبون هو ${PharmacyRepository.formatIqd(coupon.minOrderIqd)}")
                } else {
                    _appliedCoupon.value = coupon
                    showSnackbar("تم تفعيل الكوبون بنجاح! خصم ${coupon.discountPercent}%")
                }
            } else {
                showSnackbar("رمز الكوبون غير صحيح أو منتهي الصلاحية")
            }
        }
    }

    fun removeCoupon() {
        _appliedCoupon.value = null
    }

    // Checkout Details
    var customerName = MutableStateFlow("أحمد حيدر")
    var customerPhone = MutableStateFlow("07701234567")
    var customerAddress = MutableStateFlow("حي المنصور - شارع 14 رمضان")
    var selectedGovernorate = MutableStateFlow("بغداد")
    var deliveryType = MutableStateFlow("DELIVERY") // "DELIVERY" or "PICKUP"
    var orderNotes = MutableStateFlow("")

    fun submitOrder(onSuccess: (OrderEntity) -> Unit) {
        viewModelScope.launch {
            val result = repository.placeOrder(
                customerName = customerName.value.trim().ifEmpty { "عميل صيدلية الحود" },
                customerPhone = customerPhone.value.trim().ifEmpty { "07700000000" },
                deliveryAddress = customerAddress.value.trim().ifEmpty { "بغداد" },
                governorate = selectedGovernorate.value,
                deliveryType = deliveryType.value,
                cartItems = _cart.value.values.toList(),
                appliedCoupon = _appliedCoupon.value,
                notes = orderNotes.value.trim()
            )

            result.onSuccess { order ->
                clearCart()
                showSnackbar("تم إرسال طلبك بنجاح برقم ${order.id}")
                onSuccess(order)
            }.onFailure { err ->
                showSnackbar(err.message ?: "فشل إرسال الطلب")
            }
        }
    }

    // Favorites
    private val _favorites = MutableStateFlow<Set<Long>>(setOf(1L, 4L, 9L))
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    fun toggleFavorite(productId: Long) {
        val current = _favorites.value.toMutableSet()
        if (current.contains(productId)) {
            current.remove(productId)
            showSnackbar("تم الحذف من المفضلة")
        } else {
            current.add(productId)
            showSnackbar("تمت الإضافة إلى المفضلة")
        }
        _favorites.value = current
    }

    // User Roles & Authentication
    private val _userRole = MutableStateFlow(UserRole.CUSTOMER)
    val userRole: StateFlow<UserRole> = _userRole.asStateFlow()

    fun switchRole(newRole: UserRole) {
        _userRole.value = newRole
        showSnackbar("تم التبديل إلى: ${newRole.titleAr}")
    }

    fun verifyAndLoginAdmin(pin: String, onSuccess: () -> Unit, onError: () -> Unit) {
        val currentPin = pharmacySettings.value?.adminPin ?: "1234"
        if (pin.trim() == currentPin) {
            _userRole.value = UserRole.OWNER
            showSnackbar("مرحباً بك د. أحمد الحود (لوحة الإدارة مفعلة)")
            onSuccess()
        } else {
            onError()
        }
    }

    // Admin Dashboard Operations
    fun quickUpdatePrice(productId: Long, newPrice: Long, origPrice: Long, discount: Int) {
        viewModelScope.launch {
            val operator = if (_userRole.value == UserRole.OWNER) "صاحب الصيدلية" else "الصيدلي المناوب"
            repository.quickUpdatePrice(productId, newPrice, origPrice, discount, operator)
            showSnackbar("تم تحديث السعر بنجاح!")
        }
    }

    fun quickUpdateStock(productId: Long, newStock: Int, isAvailable: Boolean) {
        viewModelScope.launch {
            val operator = if (_userRole.value == UserRole.OWNER) "صاحب الصيدلية" else "الصيدلي المناوب"
            repository.quickUpdateStock(productId, newStock, isAvailable, operator)
            showSnackbar("تم تحديث كمية المخزون بنجاح!")
        }
    }

    fun saveProduct(product: ProductEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            val operator = if (_userRole.value == UserRole.OWNER) "صاحب الصيدلية" else "الصيدلي المناوب"
            repository.saveProduct(product, operator)
            showSnackbar("تم حفظ بيانات الدواء في النظام")
            onDone()
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            val operator = if (_userRole.value == UserRole.OWNER) "صاحب الصيدلية" else "الصيدلي المناوب"
            repository.deleteProduct(product, operator)
            showSnackbar("تم حذف الدواء من الكتالوج")
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            val operator = if (_userRole.value == UserRole.OWNER) "صاحب الصيدلية" else "الصيدلي المناوب"
            repository.updateOrderStatus(orderId, newStatus, operator)
            showSnackbar("تم تحديث حالة الطلب $orderId إلى: $newStatus")
        }
    }

    fun updatePharmacySettings(settings: PharmacySettingsEntity) {
        viewModelScope.launch {
            repository.updateSettings(settings, "صاحب الصيدلية")
            showSnackbar("تم حفظ إعدادات الصيدلية وتحديثها للزبائن")
        }
    }

    // Social & Community Features
    fun toggleLikePost(post: SocialPostEntity) {
        viewModelScope.launch {
            repository.toggleLikePost(post.id, post.isLikedByMe)
        }
    }

    fun addSocialPost(title: String, content: String, categoryTag: String) {
        viewModelScope.launch {
            repository.createSocialPost(title, content, categoryTag, "صيدلية الحود الذكية")
            showSnackbar("تم نشر المنشور في مجتمع الصيدلية")
        }
    }

    fun deleteSocialPost(post: SocialPostEntity) {
        viewModelScope.launch {
            repository.deleteSocialPost(post)
            showSnackbar("تم حذف المنشور")
        }
    }

    fun addComment(productId: Long?, postId: Long?, text: String, rating: Int) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val userName = if (_userRole.value == UserRole.OWNER) "د. أحمد الحود (صاحب الصيدلية)" else customerName.value
            val role = _userRole.value.name
            repository.addComment(
                productId = productId,
                postId = postId,
                userName = userName,
                userRole = role,
                text = text.trim(),
                rating = rating,
                isVerified = true
            )
            showSnackbar("تمت إضافة تعليقك وتقييمك بنجاح")
        }
    }

    fun replyToComment(commentId: Long, replyText: String) {
        if (replyText.isBlank()) return
        viewModelScope.launch {
            repository.replyToComment(commentId, replyText.trim(), "صيدلية الحود الذكية (الحساب الرسمي)")
            showSnackbar("تم إرسال الرد الرسمي للصيدلية")
        }
    }

    fun hideComment(commentId: Long, hidden: Boolean) {
        viewModelScope.launch {
            repository.hideComment(commentId, hidden)
            showSnackbar(if (hidden) "تم إخفاء التعليق" else "تم إظهار التعليق")
        }
    }

    fun reportComment(commentId: Long) {
        viewModelScope.launch {
            repository.reportComment(commentId)
            showSnackbar("تم الإبلاغ عن التعليق، سيتم مراجعته من قبل إدارة الصيدلية")
        }
    }

    fun deleteComment(commentId: Long) {
        viewModelScope.launch {
            repository.deleteComment(commentId)
            showSnackbar("تم حذف التعليق نهائياً")
        }
    }

    // Smart Medicine Request (Feature 14.A)
    fun submitMedicineRequest(medicineName: String, notes: String, onSuccess: () -> Unit) {
        if (medicineName.isBlank()) {
            showSnackbar("يرجى كتابة اسم الدواء أو المادة الفعالة")
            return
        }
        viewModelScope.launch {
            repository.submitMedicineRequest(
                medicineName = medicineName.trim(),
                customerName = customerName.value,
                customerPhone = customerPhone.value,
                notes = notes.trim()
            )
            showSnackbar("تم تسجيل طلب توفير الدواء بنجاح، سنقوم بإبلاغك فور وصوله!")
            onSuccess()
        }
    }

    fun markMedicineRequestStatus(requestId: Long, status: String) {
        viewModelScope.launch {
            repository.updateMedicineRequestStatus(requestId, status)
            showSnackbar("تم تحديث حالة طلب توفير الدواء إلى: $status")
        }
    }

    // Snackbar notifications
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }
}
