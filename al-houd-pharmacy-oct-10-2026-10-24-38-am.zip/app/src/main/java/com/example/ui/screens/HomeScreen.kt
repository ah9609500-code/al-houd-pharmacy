package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.CategoryEntity
import com.example.data.model.ProductEntity
import com.example.ui.PharmacyViewModel
import com.example.ui.components.ProductCard
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyPrimary

@Composable
fun HomeScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val featuredProducts by viewModel.featuredProducts.collectAsStateWithLifecycle()
    val discountedProducts by viewModel.discountedProducts.collectAsStateWithLifecycle()
    val bestSellers by viewModel.bestSellerProducts.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val socialPosts by viewModel.allPosts.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val pharmacySettings by viewModel.pharmacySettings.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Promotional Hero Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp)),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.banner_pharmacy_offers),
                        contentDescription = "عروض صيدلية الحود الذكية",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Gradient overlay with Arabic text
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color(0xCC062E1E))
                                )
                            )
                            .padding(16.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Column {
                            Surface(
                                color = PharmacyBadgeGreen,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "توصيل مجاني للطلبات فوق 35,000 د.ع",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "صيدلية الحود الذكية • المنصور - بغداد",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                            Text(
                                text = "رعايتكم الصحية أمانتنا - استشارة صيدلانية مجانية على مدار الساعة",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // 2. Quick Action Shortcuts
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    title = "طلب دواء خاص",
                    subtitle = "غير متوفر؟",
                    icon = Icons.Filled.SendToMobile,
                    containerColor = Color(0xFFE0F2FE),
                    iconTint = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo("medicine_request") }
                )
                QuickActionItem(
                    title = "المجتمع والنصائح",
                    subtitle = "توعية دوائية",
                    icon = Icons.Filled.Groups,
                    containerColor = Color(0xFFDCFCE7),
                    iconTint = PharmacyPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo("community") }
                )
                QuickActionItem(
                    title = "مقارنة الأدوية",
                    subtitle = "البدائل والأسعار",
                    icon = Icons.Filled.CompareArrows,
                    containerColor = Color(0xFFFEF3C7),
                    iconTint = Color(0xFFD97706),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo("compare") }
                )
            }
        }

        // 3. Category Selector Chips
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                SectionHeader(
                    title = "الأقسام والتصنيفات الطبية",
                    actionTitle = "عرض الكل",
                    onActionClick = { viewModel.navigateTo("categories") }
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(categories) { cat ->
                        CategoryCard(
                            category = cat,
                            onClick = {
                                viewModel.setCategoryFilter(cat.id)
                                viewModel.navigateTo("categories")
                            }
                        )
                    }
                }
            }
        }

        // 4. Featured Products (منتجات مميزة)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                SectionHeader(
                    title = "أدوية ومستلزمات مميزة",
                    actionTitle = "المزيد",
                    onActionClick = {
                        viewModel.setSortFilter("featured")
                        viewModel.navigateTo("categories")
                    }
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(featuredProducts) { product ->
                        ProductCard(
                            product = product,
                            isFavorite = favorites.contains(product.id),
                            onProductClick = { viewModel.selectProduct(product) },
                            onAddToCart = { viewModel.addToCart(product) },
                            onToggleFavorite = { viewModel.toggleFavorite(product.id) },
                            modifier = Modifier.width(185.dp)
                        )
                    }
                }
            }
        }

        // 5. Special Promotional Deals (عروض وتخفيضات)
        if (discountedProducts.isNotEmpty()) {
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    SectionHeader(
                        title = "تخفيضات وعروض حصرية",
                        actionTitle = "كل العروض",
                        onActionClick = {
                            viewModel.setSortFilter("discount")
                            viewModel.navigateTo("categories")
                        }
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(discountedProducts) { product ->
                            ProductCard(
                                product = product,
                                isFavorite = favorites.contains(product.id),
                                onProductClick = { viewModel.selectProduct(product) },
                                onAddToCart = { viewModel.addToCart(product) },
                                onToggleFavorite = { viewModel.toggleFavorite(product.id) },
                                modifier = Modifier.width(185.dp)
                            )
                        }
                    }
                }
            }
        }

        // 6. Best Sellers (الأكثر طلباً)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                SectionHeader(
                    title = "الأكثر مبيعاً وطلباً في الصيدلية",
                    actionTitle = "عرض الكل",
                    onActionClick = {
                        viewModel.setSortFilter("all")
                        viewModel.navigateTo("categories")
                    }
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(bestSellers) { product ->
                        ProductCard(
                            product = product,
                            isFavorite = favorites.contains(product.id),
                            onProductClick = { viewModel.selectProduct(product) },
                            onAddToCart = { viewModel.addToCart(product) },
                            onToggleFavorite = { viewModel.toggleFavorite(product.id) },
                            modifier = Modifier.width(185.dp)
                        )
                    }
                }
            }
        }

        // 7. Latest Health Awareness Tip from Community
        if (socialPosts.isNotEmpty()) {
            val latestTip = socialPosts.first()
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo("community") },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = PharmacyPrimary,
                            shape = CircleShape,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.HealthAndSafety,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = latestTip.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = latestTip.content,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.ChevronLeft,
                            contentDescription = "عرض المزيد",
                            tint = PharmacyPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    actionTitle: String,
    onActionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        TextButton(onClick = onActionClick) {
            Text(
                text = actionTitle,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Icon(
                imageVector = Icons.Filled.ChevronLeft,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun CategoryCard(
    category: CategoryEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = CardDefaults.outlinedCardBorder(),
        shadowElevation = 1.dp,
        modifier = modifier
            .width(105.dp)
            .height(115.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (category.id) {
                    "medicines" -> Icons.Filled.Medication
                    "vitamins" -> Icons.Filled.FitnessCenter
                    "skincare" -> Icons.Filled.Face
                    "devices" -> Icons.Filled.MonitorHeart
                    "baby" -> Icons.Filled.ChildCare
                    "supplies" -> Icons.Filled.Healing
                    else -> Icons.Filled.LocalPharmacy
                }
                Icon(
                    imageVector = icon,
                    contentDescription = category.nameAr,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = category.nameAr,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    containerColor: Color,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = containerColor,
        modifier = modifier.height(68.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = Color.Black.copy(alpha = 0.6f),
                    maxLines = 1
                )
            }
        }
    }
}
