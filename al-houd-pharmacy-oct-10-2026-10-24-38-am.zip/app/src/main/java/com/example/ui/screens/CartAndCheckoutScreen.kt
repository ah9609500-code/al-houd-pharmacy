package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CartItem
import com.example.data.repository.PharmacyRepository
import com.example.ui.PharmacyViewModel
import com.example.ui.components.PriceDisplay
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyPrimary

@Composable
fun CartAndCheckoutScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val subtotal by viewModel.cartSubtotal.collectAsStateWithLifecycle()
    val appliedCoupon by viewModel.appliedCoupon.collectAsStateWithLifecycle()
    val settings by viewModel.pharmacySettings.collectAsStateWithLifecycle()

    var couponCodeInput by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf(viewModel.customerName.value) }
    var customerPhone by remember { mutableStateOf(viewModel.customerPhone.value) }
    var customerAddress by remember { mutableStateOf(viewModel.customerAddress.value) }
    var selectedGov by remember { mutableStateOf(viewModel.selectedGovernorate.value) }
    var deliveryOption by remember { mutableStateOf(viewModel.deliveryType.value) } // "DELIVERY" or "PICKUP"
    var notes by remember { mutableStateOf("") }

    val freeDeliveryThreshold = settings?.freeDeliveryThresholdIqd ?: 35000L
    val baseDeliveryFee = settings?.deliveryFeeIqd ?: 3000L
    val isFreeDelivery = deliveryOption == "PICKUP" || subtotal >= freeDeliveryThreshold
    val currentDeliveryFee = if (isFreeDelivery) 0L else baseDeliveryFee

    val discountAmount = if (appliedCoupon != null) {
        (subtotal * appliedCoupon!!.discountPercent / 100).coerceAtMost(appliedCoupon!!.maxDiscountIqd)
    } else 0L

    val finalTotal = (subtotal - discountAmount + currentDeliveryFee).coerceAtLeast(0L)

    if (cart.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.RemoveShoppingCart,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    tint = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "سلة المشتريات فارغة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "تصفح أدوية ومستلزمات صيدلية الحود وأضف ما تحتاجه لسلة التسوق",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = { viewModel.navigateTo("categories") },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تصفح الأدوية والمنتجات")
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("cart_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Free Delivery Progress Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (subtotal >= freeDeliveryThreshold) Color(0xFFDCFCE7) else Color(0xFFE0F2FE)
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (subtotal >= freeDeliveryThreshold) Icons.Filled.CheckCircle else Icons.Filled.LocalShipping,
                        contentDescription = null,
                        tint = if (subtotal >= freeDeliveryThreshold) PharmacyBadgeGreen else Color(0xFF0284C7)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        if (subtotal >= freeDeliveryThreshold) {
                            Text(
                                text = "مبارك! حصلت على توصيل مجاني مباشر",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF166534)
                            )
                        } else {
                            val diff = freeDeliveryThreshold - subtotal
                            Text(
                                text = "أضف ${PharmacyRepository.formatIqd(diff)} للحصول على توصيل مجاني!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF0369A1)
                            )
                        }
                    }
                }
            }
        }

        // Cart Items List
        items(cart.values.toList()) { cartItem ->
            CartItemRow(
                item = cartItem,
                onIncrease = { viewModel.updateCartQuantity(cartItem.product.id, 1) },
                onDecrease = { viewModel.updateCartQuantity(cartItem.product.id, -1) },
                onRemove = { viewModel.removeFromCart(cartItem.product.id) }
            )
        }

        // Promo Coupon Input
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "كوبون الخصم أو الرمز الترويجي",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (appliedCoupon != null) {
                        Surface(
                            color = Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Discount, contentDescription = null, tint = PharmacyPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "تم تفعيل كود [${appliedCoupon!!.code}] - خصم ${appliedCoupon!!.discountPercent}%",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = PharmacyPrimary
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.removeCoupon() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "إزالة الكوبون", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = couponCodeInput,
                                onValueChange = { couponCodeInput = it.uppercase() },
                                placeholder = { Text("مثال: ALHOUD10", fontSize = 12.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                            Button(
                                onClick = {
                                    viewModel.applyCoupon(couponCodeInput)
                                    couponCodeInput = ""
                                },
                                enabled = couponCodeInput.isNotBlank(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("تطبيق")
                            }
                        }
                    }
                }
            }
        }

        // Delivery Method Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "طريقة استلام الطلب",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            onClick = { deliveryOption = "DELIVERY" },
                            shape = RoundedCornerShape(12.dp),
                            color = if (deliveryOption == "DELIVERY") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (deliveryOption == "DELIVERY") CardDefaults.outlinedCardBorder() else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.DeliveryDining, contentDescription = null, tint = PharmacyPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("توصيل للمنزل", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = if (isFreeDelivery) "مجاني" else PharmacyRepository.formatIqd(baseDeliveryFee),
                                    fontSize = 11.sp,
                                    color = if (isFreeDelivery) PharmacyBadgeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            onClick = { deliveryOption = "PICKUP" },
                            shape = RoundedCornerShape(12.dp),
                            color = if (deliveryOption == "PICKUP") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (deliveryOption == "PICKUP") CardDefaults.outlinedCardBorder() else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.Storefront, contentDescription = null, tint = PharmacyPrimary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("استلام من الفرع", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("صيدلية المنصور - مجاناً", fontSize = 11.sp, color = PharmacyBadgeGreen)
                            }
                        }
                    }
                }
            }
        }

        // Customer Details Form (Only needed if delivery)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "بيانات المستلم وعنوان التوصيل",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("الاسم الكامل") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("رقم الهاتف (آسيا سيل أو زين)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    if (deliveryOption == "DELIVERY") {
                        OutlinedTextField(
                            value = selectedGov,
                            onValueChange = { selectedGov = it },
                            label = { Text("المحافظة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = customerAddress,
                            onValueChange = { customerAddress = it },
                            label = { Text("العنوان بالتفصيل (المنطقة، الزقاق، أقرب نقطة دالة)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات خاصة للصيدلي أو المندوب (اختياري)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        // Payment Method & Order Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "ملخص الحساب والدفع",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Divider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مجموع المنتجات:", fontSize = 13.sp)
                        Text(PharmacyRepository.formatIqd(subtotal), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }

                    if (discountAmount > 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الخصم الترويجي:", fontSize = 13.sp, color = PharmacyBadgeGreen)
                            Text("- ${PharmacyRepository.formatIqd(discountAmount)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PharmacyBadgeGreen)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("أجور التوصيل:", fontSize = 13.sp)
                        Text(
                            text = if (currentDeliveryFee == 0L) "مجاني" else PharmacyRepository.formatIqd(currentDeliveryFee),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = if (currentDeliveryFee == 0L) PharmacyBadgeGreen else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Divider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("المجموع النهائي:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            text = PharmacyRepository.formatIqd(finalTotal),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Payments, contentDescription = null, tint = PharmacyPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "طريقة الدفع: الدفع نقداً عند الاستلام (كاش) بعد استلام وفحص الأدوية.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            viewModel.customerName.value = customerName
                            viewModel.customerPhone.value = customerPhone
                            viewModel.customerAddress.value = customerAddress
                            viewModel.selectedGovernorate.value = selectedGov
                            viewModel.deliveryType.value = deliveryOption
                            viewModel.orderNotes.value = notes

                            viewModel.submitOrder { order ->
                                viewModel.navigateTo("orders")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_order_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأكيد وإرسال الطلب (${PharmacyRepository.formatIqd(finalTotal)})", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.product.nameAr,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "${item.product.dosageForm} • ${PharmacyRepository.formatIqd(item.product.priceIqd)} للواحدة",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                PriceDisplay(
                    priceIqd = item.product.priceIqd * item.quantity
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDecrease, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (item.quantity == 1) Icons.Filled.DeleteOutline else Icons.Filled.Remove,
                        contentDescription = "تقليل",
                        tint = if (item.quantity == 1) Color.Red else MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = "${item.quantity}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(onClick = onIncrease, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.Add, contentDescription = "زيادة")
                }
            }
        }
    }
}
