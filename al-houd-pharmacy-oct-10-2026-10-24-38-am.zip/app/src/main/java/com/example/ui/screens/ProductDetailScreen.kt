package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CommentEntity
import com.example.data.model.ProductEntity
import com.example.data.model.UserRole
import com.example.data.repository.PharmacyRepository
import com.example.ui.PharmacyViewModel
import com.example.ui.components.PriceDisplay
import com.example.ui.components.StatusBadge
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyBadgeRed
import com.example.ui.theme.PharmacyPrimary

@Composable
fun ProductDetailScreen(
    product: ProductEntity,
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val userRole by viewModel.userRole.collectAsStateWithLifecycle()
    val isFavorite = favorites.contains(product.id)

    val commentsFlow = remember(product.id) { viewModel.repository.getCommentsForProduct(product.id) }
    val comments by commentsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    var quantity by remember { mutableIntStateOf(1) }
    var newCommentText by remember { mutableStateOf("") }
    var newRating by remember { mutableIntStateOf(5) }
    var replyingToCommentId by remember { mutableStateOf<Long?>(null) }
    var replyText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("product_detail_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Top Image Header with Action Icons
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                // Large Medical Icon
                val icon = when (product.iconKey) {
                    "medication" -> Icons.Filled.Medication
                    "vaccines" -> Icons.Filled.Vaccines
                    "fitness_center" -> Icons.Filled.FitnessCenter
                    "face" -> Icons.Filled.Face
                    "monitor_heart" -> Icons.Filled.MonitorHeart
                    "child_care" -> Icons.Filled.ChildCare
                    "healing" -> Icons.Filled.Healing
                    else -> Icons.Filled.LocalPharmacy
                }
                Icon(
                    imageVector = icon,
                    contentDescription = product.nameAr,
                    modifier = Modifier
                        .size(100.dp)
                        .align(Alignment.Center),
                    tint = MaterialTheme.colorScheme.primary
                )

                // Back button & Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalIconButton(
                        onClick = { viewModel.navigateBack() },
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Icon(Icons.Filled.ArrowForward, contentDescription = "رجوع")
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalIconButton(
                            onClick = { viewModel.addToCompare(product) },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Icon(Icons.Filled.CompareArrows, contentDescription = "مقارنة")
                        }

                        FilledTonalIconButton(
                            onClick = { viewModel.toggleFavorite(product.id) },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "المفضلة",
                                tint = if (isFavorite) PharmacyBadgeRed else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Expiry and Batch pill at bottom of header
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "التشغيلة: ${product.batchNumber} • الصلاحية حتى: ${product.expiryDate}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // 2. Product Title & Medical Badges
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadge(
                        status = if (product.stockQuantity <= 0) "OUT_OF_STOCK" else if (product.stockQuantity <= product.minStockAlert) "LOW_STOCK" else "IN_STOCK"
                    )

                    if (product.requiresPrescription) {
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Description, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("يلزم وصفة طبية", color = Color(0xFF1D4ED8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = product.nameAr,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = product.nameEn,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                PriceDisplay(
                    priceIqd = product.priceIqd,
                    originalPriceIqd = product.originalPriceIqd,
                    large = true
                )
            }
        }

        // 3. Action Bar: Quantity & Add to Cart
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quantity selector
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { if (quantity > 1) quantity-- },
                            enabled = quantity > 1,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Filled.Remove, contentDescription = "تقليل")
                        }
                        Text(
                            text = "$quantity",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(
                            onClick = { if (quantity < product.stockQuantity) quantity++ },
                            enabled = quantity < product.stockQuantity,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "زيادة")
                        }
                    }

                    // Add to cart button
                    Button(
                        onClick = { viewModel.addToCart(product, quantity) },
                        enabled = product.isAvailable && product.stockQuantity > 0,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("add_to_cart_button")
                    ) {
                        Icon(Icons.Filled.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (product.stockQuantity > 0) "إضافة للسلة (${PharmacyRepository.formatIqd(product.priceIqd * quantity)})" else "غير متوفر بالمخزن",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 4. Clinical Specifications
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "المعلومات الصيدلانية والعلمية",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Divider()
                    DetailRow(label = "الاسم العلمي (Generic):", value = product.genericName)
                    DetailRow(label = "المادة الفعالة والتركيز:", value = product.activeIngredient)
                    DetailRow(label = "الشكل الدوائي:", value = product.dosageForm)
                    DetailRow(label = "الشركة المصنعة:", value = product.manufacturer)
                    DetailRow(label = "الكمية المتوفرة بالمخزن:", value = "${product.stockQuantity} وحدة")
                }
            }
        }

        // 5. Usage & Safety Guidelines
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "دواعي الاستعمال وطريقة الاستخدام",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = product.descriptionAr,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "طريقة الاستخدام والجرعة:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = product.usageInstructions,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }

                    Surface(
                        color = Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تحذيرات وموانع الاستعمال:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFDC2626)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = product.warnings,
                                fontSize = 12.sp,
                                color = Color(0xFF991B1B),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // 6. Customer Discussions & Ratings Section
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "آراء واستفسارات المراجعين (${comments.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Add Comment Box
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("أضف تقييمك واستفسارك:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Row {
                                for (star in 1..5) {
                                    IconButton(
                                        onClick = { newRating = star },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (star <= newRating) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                            contentDescription = null,
                                            tint = Color(0xFFEAB308),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = newCommentText,
                            onValueChange = { newCommentText = it },
                            placeholder = { Text("اكتب رأيك أو سؤالك عن هذا الدواء...", fontSize = 12.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                viewModel.addComment(
                                    productId = product.id,
                                    postId = null,
                                    text = newCommentText,
                                    rating = newRating
                                )
                                newCommentText = ""
                            },
                            enabled = newCommentText.isNotBlank(),
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إرسال التعليق", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 7. Comments List
        items(comments) { comment ->
            CommentItemCard(
                comment = comment,
                isOwner = userRole == UserRole.OWNER || userRole == UserRole.PHARMACIST,
                onReply = {
                    replyingToCommentId = comment.id
                },
                onHide = { viewModel.hideComment(comment.id, !comment.isHidden) },
                onReport = { viewModel.reportComment(comment.id) },
                onDelete = { viewModel.deleteComment(comment.id) },
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }

    // Pharmacy Reply Dialog (Owner/Pharmacist)
    if (replyingToCommentId != null) {
        AlertDialog(
            onDismissRequest = { replyingToCommentId = null },
            title = { Text("الرد الرسمي لصيدلية الحود") },
            text = {
                OutlinedTextField(
                    value = replyText,
                    onValueChange = { replyText = it },
                    placeholder = { Text("اكتب رد الصيدلي الرسمي...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        replyingToCommentId?.let { id ->
                            viewModel.replyToComment(id, replyText)
                        }
                        replyText = ""
                        replyingToCommentId = null
                    }
                ) {
                    Text("إرسال الرد")
                }
            },
            dismissButton = {
                TextButton(onClick = { replyingToCommentId = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun CommentItemCard(
    comment: CommentEntity,
    isOwner: Boolean,
    onReply: () -> Unit,
    onHide: () -> Unit,
    onReport: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = comment.userName.take(1),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = comment.userName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    if (comment.isVerifiedPurchase) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "شراء مؤكد",
                                color = Color(0xFF15803D),
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Row {
                    for (i in 1..5) {
                        Icon(
                            imageVector = if (i <= comment.rating) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = null,
                            tint = Color(0xFFEAB308),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = comment.commentText,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )

            // Official Pharmacy Reply if present
            if (comment.replyText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Verified, contentDescription = null, tint = PharmacyPrimary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = comment.replyBy ?: "صيدلية الحود الذكية",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = PharmacyPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = comment.replyText,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Action row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.End
            ) {
                if (isOwner) {
                    TextButton(onClick = onReply, contentPadding = PaddingValues(horizontal = 6.dp)) {
                        Text("الرد كصيدلية", fontSize = 11.sp)
                    }
                    TextButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 6.dp)) {
                        Text("حذف", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                } else {
                    TextButton(onClick = onReport, contentPadding = PaddingValues(horizontal = 6.dp)) {
                        Text("إبلاغ", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
