package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        CategoryEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
        SocialPostEntity::class,
        CommentEntity::class,
        MedicineRequestEntity::class,
        CouponEntity::class,
        PharmacySettingsEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PharmacyDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
    abstract fun orderDao(): OrderDao
    abstract fun socialDao(): SocialDao
    abstract fun extraDao(): ExtraDao

    companion object {
        @Volatile
        private var INSTANCE: PharmacyDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): PharmacyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PharmacyDatabase::class.java,
                    "al_houd_pharmacy_db"
                )
                .addCallback(PharmacyDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class PharmacyDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: PharmacyDatabase) {
            // Seed Categories
            val categories = listOf(
                CategoryEntity("medicines", "أدوية عامة ومزمنة", "Medicines", "medication", "الأدوية الطبية والعلاجية العامة وعلاجات الأمراض المزمنة", 1),
                CategoryEntity("vitamins", "فيتامينات ومكملات", "Vitamins & Supplements", "fitness_center", "مكملات غذائية، معادن، مقويات، وفيتامينات عضوية متكاملة", 2),
                CategoryEntity("skincare", "عناية بالبشرة والتجميل", "Skincare", "face", "مرطبات، واقيات شمس، غسولات طبية وعلاجات ديرماتولوجية", 3),
                CategoryEntity("devices", "أجهزة طبية وتشخيصية", "Medical Devices", "monitor_heart", "أجهزة قياس الضغط، السكر، الحرارة، وأجهزة الاستنشاق والتبخير", 4),
                CategoryEntity("baby", "صحة الأم والطفل", "Mother & Baby", "child_care", "حليب الرضع، مستلزمات التغذية، العناية بالطفل وبشرة الرضع", 5),
                CategoryEntity("supplies", "مستلزمات وإسعافات", "Medical Supplies", "healing", "ضمادات، معقمات، شاش، مشدات طبية ومستلزمات العناية بالجروح", 6)
            )
            db.productDao().insertCategories(categories)

            // Seed Products
            val products = listOf(
                ProductEntity(
                    id = 1,
                    nameAr = "بنادول إكسترا - أحمر (سريع المفعول)",
                    nameEn = "Panadol Extra Tablets",
                    genericName = "Paracetamol + Caffeine",
                    activeIngredient = "باراسيتامول 500 ملغم + كافيين 65 ملغم",
                    strength = "500mg / 65mg",
                    dosageForm = "أقراص مغلفة (24 قرص)",
                    manufacturer = "GSK - GlaxoSmithKline",
                    categoryId = "medicines",
                    priceIqd = 3500,
                    originalPriceIqd = 4000,
                    costPriceIqd = 2400,
                    discountPercent = 12,
                    stockQuantity = 48,
                    minStockAlert = 8,
                    batchNumber = "BCH-GSK-992",
                    expiryDate = "2027-09",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "مسكن قوي وسريع المفعول لآلام الرأس الحادة، الصداع النصفي، آلام الأسنان، آلام الظهر، والتهاب المفاصل، وخافض للحرارة. معزز بالكافيين لتسريع الامتصاص.",
                    usageInstructions = "قرص إلى قرصين كل 4 إلى 6 ساعات عند الحاجة. لا يتجاوز 8 أقراص خلال 24 ساعة.",
                    warnings = "تجنب تناوله مع مشروبات الطاقة أو القهوة بكميات كبيرة. غير مناسب للمرضى الذين يعانون من حساسية الباراسيتامول أو ارتفاع ضغط الدم الشديد غير المسيطر عليه.",
                    iconKey = "medication",
                    isFeatured = true,
                    isBestSeller = true,
                    salesCount = 142,
                    rating = 4.9f,
                    ratingCount = 38
                ),
                ProductEntity(
                    id = 2,
                    nameAr = "أوجمنتين 1 غرام (مضاد حيوي واسع المدى)",
                    nameEn = "Augmentin 1g Tablets",
                    genericName = "Amoxicillin + Clavulanate Potassium",
                    activeIngredient = "أموكسيسيللين 875 ملغم + كلافولانات البوتاسيوم 125 ملغم",
                    strength = "1000mg",
                    dosageForm = "أقراص مغلفة (14 قرص)",
                    manufacturer = "GSK / SmithKline",
                    categoryId = "medicines",
                    priceIqd = 14000,
                    originalPriceIqd = 15000,
                    costPriceIqd = 11200,
                    discountPercent = 7,
                    stockQuantity = 24,
                    minStockAlert = 6,
                    batchNumber = "BCH-AUG-441",
                    expiryDate = "2026-11",
                    isAvailable = true,
                    requiresPrescription = true,
                    descriptionAr = "مضاد حيوي تركيبي واسع الطيف يعالج التهابات الجهاز التنفسي العلوي والسفلي، الجيوب الأنفية، الأذن الوسطى، والمسالك البولية.",
                    usageInstructions = "قرص واحد كل 12 ساعة بعد وجبة الطعام مباشرة لتفادي اضطراب المعدة. يجب إكمال الكورس العلاجي بالكامل.",
                    warnings = "يُصرف بموجب وصفة طبية مصدقة. يمنع استخدامه لمرضى حساسية البنسلين أو اليرقان الركودي السابق.",
                    iconKey = "vaccines",
                    isFeatured = true,
                    isBestSeller = true,
                    salesCount = 89,
                    rating = 4.8f,
                    ratingCount = 27
                ),
                ProductEntity(
                    id = 3,
                    nameAr = "ساماموكس 500 ملغم (كبسول سامراء)",
                    nameEn = "Samamox 500mg Capsules",
                    genericName = "Amoxicillin Trihydrate",
                    activeIngredient = "أموكسيسيللين ترايهيدرات 500 ملغم",
                    strength = "500mg",
                    dosageForm = "كبسولات (20 كبسولة)",
                    manufacturer = "SDI Samarra - الشركة العامة لصناعة الأدوية سامراء",
                    categoryId = "medicines",
                    priceIqd = 4000,
                    originalPriceIqd = 0,
                    costPriceIqd = 2800,
                    discountPercent = 0,
                    stockQuantity = 55,
                    minStockAlert = 10,
                    batchNumber = "SDI-SMX-2026",
                    expiryDate = "2027-05",
                    isAvailable = true,
                    requiresPrescription = true,
                    descriptionAr = "دواء عراقي وطني عالي الجودة لعلاج الالتهابات البكتيرية في الجهاز التنفسي والجلد والأسنان من إنتاج مصانع سامراء المعتمدة.",
                    usageInstructions = "كبسولة واحدة كل 8 ساعات بانتظام مع كوب ماء وفير.",
                    warnings = "يُصرف بوصفة طبية. ممنوع لمرضى حساسية مركبات البنسيلين.",
                    iconKey = "medication",
                    isFeatured = false,
                    isBestSeller = false,
                    salesCount = 45,
                    rating = 4.7f,
                    ratingCount = 15
                ),
                ProductEntity(
                    id = 4,
                    nameAr = "أوميغا 3 تريبل سترينث (1200 ملغم كبسول جيلاتيني)",
                    nameEn = "Omega-3 Triple Strength 1200mg",
                    genericName = "Omega 3 Fish Oil (EPA & DHA)",
                    activeIngredient = "زيت سمك نقي مركز (EPA 720mg / DHA 480mg)",
                    strength = "1200mg",
                    dosageForm = "كبسولات جيلاتينية رخوة (60 كبسولة)",
                    manufacturer = "Solgar USA",
                    categoryId = "vitamins",
                    priceIqd = 24000,
                    originalPriceIqd = 28000,
                    costPriceIqd = 18500,
                    discountPercent = 14,
                    stockQuantity = 22,
                    minStockAlert = 5,
                    batchNumber = "SLG-OMG-771",
                    expiryDate = "2028-01",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "مكمل غذائي ممتاز لصحة القلب والشرايين، تعزيز الذاكرة والتركيز، تقليل الدهون الثلاثية الضارة، ودعم مرونة المفاصل وصحة العين.",
                    usageInstructions = "كبسولة واحدة يومياً مع وجبة رئيسية دسمة.",
                    warnings = "استشر الطبيب إذا كنت تتناول مميعات الدم (مثل الوارفارين أو الأسبرين). خالي من الزئبق والمعادن الثقيلة.",
                    iconKey = "fitness_center",
                    isFeatured = true,
                    isBestSeller = true,
                    salesCount = 98,
                    rating = 5.0f,
                    ratingCount = 42
                ),
                ProductEntity(
                    id = 5,
                    nameAr = "فيتامين سي 1000 ملغم + زنك (أقراص فوارة بنكهة البرتقال)",
                    nameEn = "Vitamin C 1000mg + Zinc Effervescent",
                    genericName = "Ascorbic Acid + Zinc Sulphate",
                    activeIngredient = "فيتامين ج 1000 ملغم + زنك 10 ملغم",
                    strength = "1000mg + 10mg",
                    dosageForm = "أقراص فوارة (20 قرص)",
                    manufacturer = "Doppelherz - Germany",
                    categoryId = "vitamins",
                    priceIqd = 8500,
                    originalPriceIqd = 10000,
                    costPriceIqd = 6200,
                    discountPercent = 15,
                    stockQuantity = 38,
                    minStockAlert = 8,
                    batchNumber = "DOP-VCZ-501",
                    expiryDate = "2027-04",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "فوار ألماني أصلي لتقوية جهاز المناعة ومقاومة نزلات البرد والإنفلونزا، مضاد أكسدة قوي ومحفز لإنتاج الكولاجين الطبيعي في البشرة.",
                    usageInstructions = "يذاب قرص واحد في نصف كوب ماء (150 مل) ويشرب مرة واحدة يومياً صباحاً.",
                    warnings = "لا يعطى لمرضى حصوات الكلى من نوع الأوكسالات دون استشارة الطبيب.",
                    iconKey = "emoji_nature",
                    isFeatured = true,
                    isBestSeller = true,
                    salesCount = 110,
                    rating = 4.9f,
                    ratingCount = 31
                ),
                ProductEntity(
                    id = 6,
                    nameAr = "بانتوزول 40 ملغم (علاج حموضة وقرحة المعدة)",
                    nameEn = "Pantozol 40mg Gastro-Resistant Tablets",
                    genericName = "Pantoprazole Sodium Sesquihydrate",
                    activeIngredient = "بانتوبرازول صوديوم 40 ملغم",
                    strength = "40mg",
                    dosageForm = "أقراص مقاومة للمعدة (28 قرص)",
                    manufacturer = "Takeda Pharmaceuticals",
                    categoryId = "medicines",
                    priceIqd = 18500,
                    originalPriceIqd = 20000,
                    costPriceIqd = 14300,
                    discountPercent = 8,
                    stockQuantity = 18,
                    minStockAlert = 5,
                    batchNumber = "TKD-PTZ-882",
                    expiryDate = "2027-03",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "مثبط مضخة البروتون الفعال لعلاج ارتجاع المريء، حرقة الفؤاد الشديدة، وقرحة المعدة والاثني عشر.",
                    usageInstructions = "قرص واحد يومياً قبل وجبة الإفطار بنصف ساعة مع شرب ماء كافٍ.",
                    warnings = "يبلع القرص كاملاً دون مضغ أو سحق للحفاظ على الغلاف المعوي.",
                    iconKey = "medication",
                    isFeatured = false,
                    isBestSeller = false,
                    salesCount = 35,
                    rating = 4.8f,
                    ratingCount = 19
                ),
                ProductEntity(
                    id = 7,
                    nameAr = "واقي شمس لاروش بوزيه أنثيليوس SPF 50+ (سائل ضد اللمعان)",
                    nameEn = "La Roche-Posay Anthelios UVMune 400 SPF 50+",
                    genericName = "Broad Spectrum Sunscreen Fluid",
                    activeIngredient = "Mexoryl 400 + Netlock Technology",
                    strength = "SPF 50+ / 50ml",
                    dosageForm = "سائل سائل خفيف غير دهني (50 مل)",
                    manufacturer = "L'Oréal France",
                    categoryId = "skincare",
                    priceIqd = 28000,
                    originalPriceIqd = 32000,
                    costPriceIqd = 22000,
                    discountPercent = 12,
                    stockQuantity = 19,
                    minStockAlert = 4,
                    batchNumber = "LRP-ANT-331",
                    expiryDate = "2027-10",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "أفضل واقي شمس طبي فرنسي يحمي من الأشعة فوق البنفسجية الطويلة جداً UVA وUVB. سريع الامتصاص ومقاوم للماء والتعرق بدون أثر أبيض.",
                    usageInstructions = "يرج جيداً قبل الاستعمال. يوضع على الوجه والرقبة قبل التعرض للشمس بـ 20 دقيقة، ويجدد كل ساعتين.",
                    warnings = "تجنب ملامسة العينين بشكل مباشر.",
                    iconKey = "face",
                    isFeatured = true,
                    isBestSeller = true,
                    salesCount = 76,
                    rating = 5.0f,
                    ratingCount = 34
                ),
                ProductEntity(
                    id = 8,
                    nameAr = "كريم بيبانثين بلس المرطب والمطهر (30 غرام)",
                    nameEn = "Bepanthen Plus Antiseptic Cream 30g",
                    genericName = "Dexpanthenol + Chlorhexidine",
                    activeIngredient = "ديكسبانثينول 50 ملغم + كلورهيكسيدين 5 ملغم",
                    strength = "5% + 0.5%",
                    dosageForm = "كريم موضعي طبي (30 غرام)",
                    manufacturer = "Bayer Healthcare Germany",
                    categoryId = "skincare",
                    priceIqd = 7000,
                    originalPriceIqd = 8000,
                    costPriceIqd = 5200,
                    discountPercent = 12,
                    stockQuantity = 32,
                    minStockAlert = 6,
                    batchNumber = "BYR-BPN-909",
                    expiryDate = "2027-07",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "كريم مطهر ومرمم للبشرة، يعالج الجروح السطحية والخدوش والتشققات وحروق الشمس الطفيفة مع ترطيب عميق.",
                    usageInstructions = "يدهن طبقة رقيقة على المنطقة المصابة بعد تنظيفها مرة أو مرتين يومياً.",
                    warnings = "للاستخدام الخارجي فقط. لا يوضع على الجروح العميقة الملوثة أو المتقيحة.",
                    iconKey = "healing",
                    isFeatured = false,
                    isBestSeller = true,
                    salesCount = 93,
                    rating = 4.9f,
                    ratingCount = 28
                ),
                ProductEntity(
                    id = 9,
                    nameAr = "جهاز قياس ضغط الدم أومرون M3 الذكي (مع شريط مريح عريض)",
                    nameEn = "Omron M3 Comfort Blood Pressure Monitor",
                    genericName = "Digital Automatic Upper Arm BP Monitor",
                    activeIngredient = "Intelli Wrap Cuff (22-42cm)",
                    strength = "دقة معتمدة سريرياً",
                    dosageForm = "جهاز طبي كهربائي + بطاريات + محفظة",
                    manufacturer = "Omron Healthcare Japan",
                    categoryId = "devices",
                    priceIqd = 75000,
                    originalPriceIqd = 85000,
                    costPriceIqd = 62000,
                    discountPercent = 12,
                    stockQuantity = 9,
                    minStockAlert = 3,
                    batchNumber = "OMR-M3C-2026",
                    expiryDate = "2032-12",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "جهاز ضغط رقمي عالي الدقة مزود بتقنية كفة 360 درجة لقياس صحيح وموثوق في أي وضعية حول الذراع. يكتشف عدم انتظام ضربات القلب ويوضح معدل ضغط الدم.",
                    usageInstructions = "يتم القياس في وضع الجلوس والراحة لمدة 5 دقائق، مع وضع الكفة على مستوى القلب.",
                    warnings = "الجهاز مخصص للمتابعة المنزلية ولا يغني عن استشارة طبيب الباطنية والقلب.",
                    iconKey = "monitor_heart",
                    isFeatured = true,
                    isBestSeller = false,
                    salesCount = 21,
                    rating = 5.0f,
                    ratingCount = 16
                ),
                ProductEntity(
                    id = 10,
                    nameAr = "جهاز قياس السكر أكيو تشيك إنستانت + 50 شريط فحص مجاني",
                    nameEn = "Accu-Chek Instant Blood Glucose Meter",
                    genericName = "Blood Glucose Monitoring System",
                    activeIngredient = "Enzyme Biosensor with Color Range",
                    strength = "دقة متناهية 4 ثوانٍ",
                    dosageForm = "حقيبة متكاملة (جهاز + قلم وخز + 50 شريط)",
                    manufacturer = "Roche Diagnostics Germany",
                    categoryId = "devices",
                    priceIqd = 38000,
                    originalPriceIqd = 45000,
                    costPriceIqd = 30000,
                    discountPercent = 15,
                    stockQuantity = 14,
                    minStockAlert = 4,
                    batchNumber = "RCH-ACK-118",
                    expiryDate = "2027-02",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "جهاز فحص السكر الألماني الأسهل والأسرع، يظهر النتيجة فوراً مع مؤشر ملون لنطاق الهدف (طبيعي / منخفض / مرتفع). عينة دم مجهرية 0.6 ميكرولتر فقط.",
                    usageInstructions = "إدخال شريط الفحص، وخز الإصبع برفق، ووضع قطرة الدم على الحافة الصفراء للشريط.",
                    warnings = "حفظ شرائط الفحص في علبتها المغلقة بعيداً عن الرطوبة والشمس المباشرة.",
                    iconKey = "speed",
                    isFeatured = true,
                    isBestSeller = true,
                    salesCount = 54,
                    rating = 4.9f,
                    ratingCount = 23
                ),
                ProductEntity(
                    id = 11,
                    nameAr = "حليب أبتاميل أدفانس 1 للرضع (400 غرام)",
                    nameEn = "Aptamil Advance 1 Infant Formula 400g",
                    genericName = "Infant Formula with Pronutra Advance",
                    activeIngredient = "Prebiotics (GOS/FOS) + DHA & ARA",
                    strength = "من الولادة حتى 6 أشهر",
                    dosageForm = "مسحوق حليب بودرة (عبوة 400 غرام)",
                    manufacturer = "Danone Nutricia Europe",
                    categoryId = "baby",
                    priceIqd = 14500,
                    originalPriceIqd = 16000,
                    costPriceIqd = 12000,
                    discountPercent = 9,
                    stockQuantity = 28,
                    minStockAlert = 6,
                    batchNumber = "APT-ADV-552",
                    expiryDate = "2027-01",
                    isAvailable = true,
                    requiresPrescription = false,
                    descriptionAr = "تركيبة حليب أطفال غذائية متوازنة تدعم الجهاز المناعي وتطور الدماغ والنمو المتناسق للرضع من عمر يوم حتى 6 أشهر.",
                    usageInstructions = "مكيال واحد لكل 30 مل ماء مغلي مسبقاً وفاتر. رج الرضاعة جيداً حتى الذوبان الكامل.",
                    warnings = "حليب الأم هو الأفضل للرضيع. يحفظ في مكان جاف ويستهلك خلال 4 أسابيع من الفتح.",
                    iconKey = "child_care",
                    isFeatured = false,
                    isBestSeller = true,
                    salesCount = 88,
                    rating = 4.8f,
                    ratingCount = 25
                ),
                ProductEntity(
                    id = 12,
                    nameAr = "كونكور 5 ملغم (لتنظيم نبض القلب وضغط الدم)",
                    nameEn = "Concor 5mg Film-Coated Tablets",
                    genericName = "Bisoprolol Fumarate",
                    activeIngredient = "بيسوبرولول فومارات 5 ملغم",
                    strength = "5mg",
                    dosageForm = "أقراص مغلفة (30 قرص)",
                    manufacturer = "Merck Healthcare Germany",
                    categoryId = "medicines",
                    priceIqd = 12000,
                    originalPriceIqd = 0,
                    costPriceIqd = 9500,
                    discountPercent = 0,
                    stockQuantity = 3, // LOW STOCK FOR OWNER ALERT DEMO
                    minStockAlert = 5,
                    batchNumber = "MRK-CNC-710",
                    expiryDate = "2026-10",
                    isAvailable = true,
                    requiresPrescription = true,
                    descriptionAr = "حاصر مستقبلات بيتا لعلاج ارتفاع ضغط الدم والذبحة الصدرية وقصور القلب المزمن المستقر.",
                    usageInstructions = "قرص واحد صباحاً يومياً قبل أو بعد الإفطار. لا توقف العلاج فجأة بدون إشراف طبي.",
                    warnings = "يُصرف حصراً بوصفة طبية. يمنع في حالات بطء القلب الشديد والربو الحاد.",
                    iconKey = "favorite",
                    isFeatured = false,
                    isBestSeller = false,
                    salesCount = 31,
                    rating = 4.7f,
                    ratingCount = 12
                )
            )
            db.productDao().insertProducts(products)

            // Seed Settings
            val settings = PharmacySettingsEntity(
                id = 1,
                pharmacyNameAr = "صيدلية الحود الذكية",
                pharmacyNameEn = "Al-Houd Smart Pharmacy",
                slogan = "رعايتكم الصحية أمانتنا • بغداد - العراق",
                ownerName = "د. أحمد الحود (صيدلي ممارس ومعتمد)",
                phoneNumber = "+964 770 123 4567",
                whatsappNumber = "+964 780 123 4567",
                address = "العراق - بغداد - المنصور - شارع 14 رمضان (مقابل مول المنصور)",
                workingHours = "يومياً من 8:00 صباحاً حتى 12:00 منتصف الليل (توصيل فوري متاح)",
                deliveryFeeIqd = 3000,
                freeDeliveryThresholdIqd = 35000,
                minOrderAmountIqd = 5000,
                pointsPerThousandIqd = 1,
                iqdPerPointRedeemed = 50,
                adminPin = "1234"
            )
            db.extraDao().insertSettings(settings)

            // Seed Coupons
            val coupons = listOf(
                CouponEntity("ALHOUD10", 10, 15000, 10000, true, "2026-12-31"),
                CouponEntity("WELCOME5", 5, 5000, 5000, true, "2026-12-31"),
                CouponEntity("HEALTH15", 15, 30000, 15000, true, "2026-12-31")
            )
            db.extraDao().insertCoupons(coupons)

            // Seed Social Posts (Community Health Feed)
            val posts = listOf(
                SocialPostEntity(
                    id = 1,
                    authorName = "صيدلية الحود الذكية",
                    authorRole = "الحساب الرسمي للصيدلية",
                    isOfficialPharmacy = true,
                    title = "نصائح وإرشادات للوقاية أثناء العواصف الترابية وموجات الغبار في بغداد",
                    content = "أعزاءنا المراجعين والزبائن الكرام، مع موجات الغبار الحالية في العراق ننصح بتشغيل أجهزة تنقية الهواء المنزلية، وارتداء الكمامات الطبية N95 عند الخروج، واستخدام بخاخات ماء البحر الملحية لغسل الأنف. لمرضى الربو والتحسس القصبي، يرجى التأكد من توفر بخاخات الفنتولين الموسعة للشعب الهوائية لديكم وعدم التردد في استشارة صيادلتنا المناوبين في أي وقت.",
                    categoryTag = "نصيحة طبية",
                    likesCount = 64,
                    commentsCount = 8,
                    isLikedByMe = true,
                    pinned = true
                ),
                SocialPostEntity(
                    id = 2,
                    authorName = "صيدلية الحود الذكية",
                    authorRole = "الحساب الرسمي للصيدلية",
                    isOfficialPharmacy = true,
                    title = "فحص مجاني لضغط الدم ونسبة السكر بالدم طوال يوم الجمعة في فرعنا بالمنصور",
                    content = "يسر كادر صيدلية الحود الذكية أن يعلن لجميع أهالينا الكرام عن إقامة يوم الفحص الصحي المفتوح كل جمعة. تشمل المبادرة فحص ضغط الدم، فحص السكر العشوائي، وقياس مؤشر كتلة الجسم (BMI) مع استشارة صيدلانية مجانية بإشراف الدكتور أحمد الحود. صحتكم وسلامتكم غايتنا الدائمة.",
                    categoryTag = "عرض وفعالية",
                    likesCount = 92,
                    commentsCount = 14,
                    isLikedByMe = false,
                    pinned = false
                ),
                SocialPostEntity(
                    id = 3,
                    authorName = "صيدلية الحود الذكية",
                    authorRole = "الحساب الرسمي للصيدلية",
                    isOfficialPharmacy = true,
                    title = "التوعية الدوائية: الفارق الحاسم بين المضادات الحيوية ومسكنات نزلات البرد",
                    content = "نؤكد لأحبائنا أن نزلات البرد والإنفلونزا الموسمية هي عدوى فيروسية لا تعالج بالمضادات الحيوية! الاستخدام العشوائي للأوجمنتين أو الأموكسيسيلين بدون وصفة يسبب مقاومة بكتيرية خطيرة. استبدلوها بالراحة، السوائل الدافئة، فيتامين سي والزنك، واستشيروا الصيدلي دائماً قبل تناول أي دواء.",
                    categoryTag = "توعية دوائية",
                    likesCount = 78,
                    commentsCount = 6,
                    isLikedByMe = false,
                    pinned = false
                )
            )
            db.socialDao().insertPosts(posts)

            // Seed Product Comments
            val comments = listOf(
                CommentEntity(
                    productId = 1,
                    userName = "علي الكرخي",
                    userRole = "CUSTOMER",
                    commentText = "بنادول ممتاز جداً، خفف وجع الرأس بسرعة في ربع ساعة. وتوصيل الصيدلية وصلني خلال نصف ساعة للبيت بالمنصور.",
                    rating = 5,
                    isVerifiedPurchase = true,
                    replyText = "ألف سلامة عليك أستاذ علي، بخدمتكم دائماً في صيدلية الحود.",
                    replyBy = "د. أحمد الحود (صاحب الصيدلية)",
                    replyTimestamp = System.currentTimeMillis() - 86400000L,
                    likesCount = 12
                ),
                CommentEntity(
                    productId = 4,
                    userName = "أم يوسف",
                    userRole = "CUSTOMER",
                    commentText = "أوميغا سولغار الأصلي فرق وياي بالنشاط والتركيز، وبدون طعم سمك مزعج. شكراً على السعر المناسب مقارنة بالسوق.",
                    rating = 5,
                    isVerifiedPurchase = true,
                    replyText = "بالعافية والصحة أم يوسف، نحرص دائماً على توفير الماركات العالمية الأصلية الموثوقة.",
                    replyBy = "صيدلية الحود الذكية",
                    replyTimestamp = System.currentTimeMillis() - 43200000L,
                    likesCount = 7
                ),
                CommentEntity(
                    productId = 9,
                    userName = "حيدر البغدادي",
                    userRole = "CUSTOMER",
                    commentText = "جهاز أومرون دقيق جداً وقارنته مع جهاز الزئبق في العيادة وكانت القراءة مطابقة تماماً. الكفة مريحة وسهل الاستخدام للوالد.",
                    rating = 5,
                    isVerifiedPurchase = true,
                    likesCount = 9
                )
            )
            db.socialDao().insertComments(comments)

            // Seed Initial Sample Orders
            val order1 = OrderEntity(
                id = "ALH-1041",
                customerName = "كرار النداوي",
                customerPhone = "07712345678",
                deliveryAddress = "حي الجامعة - محلة 623 زقاق 14 دار 8",
                governorate = "بغداد",
                deliveryType = "DELIVERY",
                status = "COMPLETED",
                subtotalIqd = 32500,
                discountIqd = 3000,
                deliveryFeeIqd = 3000,
                totalIqd = 32500,
                paymentMethod = "CASH_ON_DELIVERY",
                notes = "يرجى رن الجرس عند الوصول",
                itemsSummary = "بنادول إكسترا (2) + واقي شمس لاروش بوزيه (1)",
                createdAt = System.currentTimeMillis() - 172800000L
            )
            val order2 = OrderEntity(
                id = "ALH-1042",
                customerName = "مروة السعدي",
                customerPhone = "07809876543",
                deliveryAddress = "اليرموك - قرب ساحة قحطان",
                governorate = "بغداد",
                deliveryType = "DELIVERY",
                status = "PREPARING",
                subtotalIqd = 46500,
                discountIqd = 0,
                deliveryFeeIqd = 0, // Free delivery because > 35,000 IQD!
                totalIqd = 46500,
                paymentMethod = "CASH_ON_DELIVERY",
                notes = "الطلب عاجل للأطفال",
                itemsSummary = "حليب أبتاميل أدفانس 1 (2) + فوار فيتامين سي وزنك (2)",
                createdAt = System.currentTimeMillis() - 3600000L
            )
            db.orderDao().insertOrder(order1)
            db.orderDao().insertOrder(order2)

            // Seed Medicine Requests (Feature 14.A)
            val request = MedicineRequestEntity(
                id = 1,
                medicineName = "حقن إينوكسابارين 4000 وحدة دولية (كلكسان Clexane)",
                customerName = "عمر الجبوري",
                customerPhone = "07705544332",
                notes = "مطلوب كورس 10 حقن ضروري بعد عملية جراحية",
                requestCount = 3,
                status = "PENDING"
            )
            db.extraDao().insertMedicineRequest(request)

            // Seed Initial Audit Log
            val audit = AuditLogEntity(
                actionType = "INITIAL_SETUP",
                performedBy = "النظام",
                details = "تم تهيئة قاعدة بيانات صيدلية الحود الذكية بالكتالوج الأولي والأسعار"
            )
            db.extraDao().insertAuditLog(audit)
        }
    }
}
