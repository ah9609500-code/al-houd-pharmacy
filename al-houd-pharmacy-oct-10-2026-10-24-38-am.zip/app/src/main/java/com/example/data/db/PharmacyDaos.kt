package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY isFeatured DESC, salesCount DESC, id DESC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE categoryId = :categoryId ORDER BY id DESC")
    fun getProductsByCategory(categoryId: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE isFeatured = 1 ORDER BY id DESC")
    fun getFeaturedProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE discountPercent > 0 ORDER BY discountPercent DESC")
    fun getDiscountedProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE isBestSeller = 1 OR salesCount > 10 ORDER BY salesCount DESC")
    fun getBestSellerProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE stockQuantity <= minStockAlert ORDER BY stockQuantity ASC")
    fun getLowStockProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    fun getProductById(id: Long): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductByIdDirect(id: Long): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("UPDATE products SET priceIqd = :priceIqd, originalPriceIqd = :originalPriceIqd, discountPercent = :discountPercent, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateProductPrice(id: Long, priceIqd: Long, originalPriceIqd: Long, discountPercent: Int, updatedAt: Long)

    @Query("UPDATE products SET stockQuantity = :stockQuantity, isAvailable = :isAvailable, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateProductStock(id: Long, stockQuantity: Int, isAvailable: Boolean, updatedAt: Long)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    // Categories
    @Query("SELECT * FROM categories ORDER BY displayOrder ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    fun getOrderById(orderId: String): Flow<OrderEntity?>

    @Query("SELECT * FROM orders WHERE status = :status ORDER BY createdAt DESC")
    fun getOrdersByStatus(status: String): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Query("UPDATE orders SET status = :status, updatedAt = :updatedAt WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String, updatedAt: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItemEntity>)

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItems(orderId: String): Flow<List<OrderItemEntity>>
}

@Dao
interface SocialDao {
    @Query("SELECT * FROM social_posts ORDER BY pinned DESC, createdAt DESC")
    fun getAllPosts(): Flow<List<SocialPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: SocialPostEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<SocialPostEntity>)

    @Update
    suspend fun updatePost(post: SocialPostEntity)

    @Delete
    suspend fun deletePost(post: SocialPostEntity)

    @Query("UPDATE social_posts SET likesCount = likesCount + :delta, isLikedByMe = :liked WHERE id = :postId")
    suspend fun updatePostLike(postId: Long, delta: Int, liked: Boolean)

    // Comments & Discussions
    @Query("SELECT * FROM comments WHERE productId = :productId AND isHidden = 0 ORDER BY createdAt DESC")
    fun getCommentsForProduct(productId: Long): Flow<List<CommentEntity>>

    @Query("SELECT * FROM comments WHERE postId = :postId AND isHidden = 0 ORDER BY createdAt DESC")
    fun getCommentsForPost(postId: Long): Flow<List<CommentEntity>>

    @Query("SELECT * FROM comments ORDER BY isReported DESC, createdAt DESC")
    fun getAllCommentsForModeration(): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComments(comments: List<CommentEntity>)

    @Query("UPDATE comments SET replyText = :replyText, replyBy = :replyBy, replyTimestamp = :timestamp WHERE id = :commentId")
    suspend fun replyToComment(commentId: Long, replyText: String, replyBy: String, timestamp: Long)

    @Query("UPDATE comments SET isHidden = :hidden WHERE id = :commentId")
    suspend fun setCommentHidden(commentId: Long, hidden: Boolean)

    @Query("UPDATE comments SET isReported = 1 WHERE id = :commentId")
    suspend fun reportComment(commentId: Long)

    @Query("DELETE FROM comments WHERE id = :commentId")
    suspend fun deleteComment(commentId: Long)
}

@Dao
interface ExtraDao {
    // Smart Medicine Requests
    @Query("SELECT * FROM medicine_requests ORDER BY requestedAt DESC")
    fun getAllMedicineRequests(): Flow<List<MedicineRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicineRequest(request: MedicineRequestEntity): Long

    @Query("UPDATE medicine_requests SET status = :status, fulfilledAt = :fulfilledAt WHERE id = :id")
    suspend fun updateMedicineRequestStatus(id: Long, status: String, fulfilledAt: Long?)

    // Coupons
    @Query("SELECT * FROM coupons WHERE isActive = 1")
    fun getAllCoupons(): Flow<List<CouponEntity>>

    @Query("SELECT * FROM coupons WHERE code = :code AND isActive = 1 LIMIT 1")
    suspend fun getCouponByCode(code: String): CouponEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCoupons(coupons: List<CouponEntity>)

    // Pharmacy Settings
    @Query("SELECT * FROM pharmacy_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<PharmacySettingsEntity?>

    @Query("SELECT * FROM pharmacy_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsDirect(): PharmacySettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettings(settings: PharmacySettingsEntity)

    @Update
    suspend fun updateSettings(settings: PharmacySettingsEntity)

    // Audit logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}
