package com.example.data.repository

import com.example.data.db.ExtraDao
import com.example.data.db.OrderDao
import com.example.data.db.ProductDao
import com.example.data.db.SocialDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.text.NumberFormat
import java.util.Locale
import kotlin.random.Random

class PharmacyRepository(
    private val productDao: ProductDao,
    private val orderDao: OrderDao,
    private val socialDao: SocialDao,
    private val extraDao: ExtraDao
) {
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val allCategories: Flow<List<CategoryEntity>> = productDao.getAllCategories()
    val featuredProducts: Flow<List<ProductEntity>> = productDao.getFeaturedProducts()
    val discountedProducts: Flow<List<ProductEntity>> = productDao.getDiscountedProducts()
    val bestSellerProducts: Flow<List<ProductEntity>> = productDao.getBestSellerProducts()
    val lowStockProducts: Flow<List<ProductEntity>> = productDao.getLowStockProducts()
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
    val allPosts: Flow<List<SocialPostEntity>> = socialDao.getAllPosts()
    val settings: Flow<PharmacySettingsEntity?> = extraDao.getSettings()
    val medicineRequests: Flow<List<MedicineRequestEntity>> = extraDao.getAllMedicineRequests()
    val auditLogs: Flow<List<AuditLogEntity>> = extraDao.getAllAuditLogs()
    val coupons: Flow<List<CouponEntity>> = extraDao.getAllCoupons()
    val allCommentsForModeration: Flow<List<CommentEntity>> = socialDao.getAllCommentsForModeration()

    fun getProductById(id: Long): Flow<ProductEntity?> = productDao.getProductById(id)
    fun getProductsByCategory(categoryId: String): Flow<List<ProductEntity>> = productDao.getProductsByCategory(categoryId)
    fun getCommentsForProduct(productId: Long): Flow<List<CommentEntity>> = socialDao.getCommentsForProduct(productId)
    fun getCommentsForPost(postId: Long): Flow<List<CommentEntity>> = socialDao.getCommentsForPost(postId)
    fun getOrderItems(orderId: String): Flow<List<OrderItemEntity>> = orderDao.getOrderItems(orderId)

    suspend fun saveProduct(product: ProductEntity, operator: String): Long {
        val id = productDao.insertProduct(product)
        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = if (product.id == 0L) "PRODUCT_ADDED" else "PRODUCT_UPDATED",
                performedBy = operator,
                details = "تم حفظ المنتج: ${product.nameAr} - السعر: ${formatIqd(product.priceIqd)} - المخزون: ${product.stockQuantity}"
            )
        )
        return id
    }

    suspend fun quickUpdatePrice(
        productId: Long,
        newPriceIqd: Long,
        originalPriceIqd: Long,
        discountPercent: Int,
        operator: String
    ) {
        val existing = productDao.getProductByIdDirect(productId)
        productDao.updateProductPrice(
            id = productId,
            priceIqd = newPriceIqd,
            originalPriceIqd = originalPriceIqd,
            discountPercent = discountPercent,
            updatedAt = System.currentTimeMillis()
        )
        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = "PRICE_UPDATE",
                performedBy = operator,
                details = "تعديل سعر [${existing?.nameAr ?: productId}] من ${formatIqd(existing?.priceIqd ?: 0)} إلى ${formatIqd(newPriceIqd)}"
            )
        )
    }

    suspend fun quickUpdateStock(
        productId: Long,
        newStock: Int,
        isAvailable: Boolean,
        operator: String
    ) {
        val existing = productDao.getProductByIdDirect(productId)
        productDao.updateProductStock(
            id = productId,
            stockQuantity = newStock,
            isAvailable = isAvailable,
            updatedAt = System.currentTimeMillis()
        )
        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = "STOCK_UPDATE",
                performedBy = operator,
                details = "تعديل مخزون [${existing?.nameAr ?: productId}] إلى $newStock وحدة (الحالة: ${if (isAvailable) "متوفر" else "غير متوفر"})"
            )
        )
    }

    suspend fun deleteProduct(product: ProductEntity, operator: String) {
        productDao.deleteProduct(product)
        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = "PRODUCT_DELETED",
                performedBy = operator,
                details = "تم حذف المنتج: ${product.nameAr}"
            )
        )
    }

    suspend fun placeOrder(
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        governorate: String,
        deliveryType: String,
        cartItems: List<CartItem>,
        appliedCoupon: CouponEntity?,
        notes: String
    ): Result<OrderEntity> {
        if (cartItems.isEmpty()) {
            return Result.failure(Exception("سلة الشراء فارغة"))
        }

        // 1. Validate real-time stock
        for (item in cartItems) {
            val dbProduct = productDao.getProductByIdDirect(item.product.id)
            if (dbProduct == null) {
                return Result.failure(Exception("المنتج ${item.product.nameAr} لم يعد متوفراً"))
            }
            if (dbProduct.stockQuantity < item.quantity) {
                return Result.failure(Exception("الكمية المطلوبة من ${dbProduct.nameAr} غير متوفرة بالمخزن. المتوفر حالياً: ${dbProduct.stockQuantity} فقط"))
            }
        }

        // 2. Calculate totals
        val subtotal = cartItems.sumOf { it.product.priceIqd * it.quantity }
        val currentSettings = extraDao.getSettingsDirect() ?: PharmacySettingsEntity()

        var discountAmount = 0L
        if (appliedCoupon != null) {
            discountAmount = (subtotal * appliedCoupon.discountPercent / 100).coerceAtMost(appliedCoupon.maxDiscountIqd)
        }

        val deliveryFee = if (deliveryType == "PICKUP" || subtotal >= currentSettings.freeDeliveryThresholdIqd) {
            0L
        } else {
            currentSettings.deliveryFeeIqd
        }

        val totalAmount = (subtotal - discountAmount + deliveryFee).coerceAtLeast(0L)

        // 3. Generate Unique Order ID
        val randomSuffix = Random.nextInt(1000, 9999)
        val orderId = "ALH-$randomSuffix"

        val summary = cartItems.joinToString(" • ") { "${it.product.nameAr} (${it.quantity})" }

        val order = OrderEntity(
            id = orderId,
            customerName = customerName,
            customerPhone = customerPhone,
            deliveryAddress = if (deliveryType == "PICKUP") "استلام ذاتي من فرع الصيدلية (المنصور)" else deliveryAddress,
            governorate = governorate,
            deliveryType = deliveryType,
            status = "NEW",
            subtotalIqd = subtotal,
            discountIqd = discountAmount,
            deliveryFeeIqd = deliveryFee,
            totalIqd = totalAmount,
            paymentMethod = "CASH_ON_DELIVERY",
            notes = notes,
            itemsSummary = summary,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        // 4. Save order & items
        orderDao.insertOrder(order)
        val orderItems = cartItems.map {
            OrderItemEntity(
                orderId = orderId,
                productId = it.product.id,
                productNameAr = it.product.nameAr,
                unitPriceIqd = it.product.priceIqd,
                quantity = it.quantity,
                totalPriceIqd = it.product.priceIqd * it.quantity
            )
        }
        orderDao.insertOrderItems(orderItems)

        // 5. Deduct inventory & increase sales count
        for (item in cartItems) {
            val dbProduct = productDao.getProductByIdDirect(item.product.id)
            if (dbProduct != null) {
                val newStock = (dbProduct.stockQuantity - item.quantity).coerceAtLeast(0)
                productDao.updateProductStock(
                    id = dbProduct.id,
                    stockQuantity = newStock,
                    isAvailable = newStock > 0,
                    updatedAt = System.currentTimeMillis()
                )
            }
        }

        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = "NEW_ORDER",
                performedBy = "الزبون: $customerName",
                details = "طلب جديد برقم $orderId بقيمة إجمالية ${formatIqd(totalAmount)}"
            )
        )

        return Result.success(order)
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String, operator: String) {
        orderDao.updateOrderStatus(orderId, newStatus, System.currentTimeMillis())
        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = "ORDER_STATUS",
                performedBy = operator,
                details = "تغيير حالة الطلب $orderId إلى: $newStatus"
            )
        )
    }

    suspend fun createSocialPost(title: String, content: String, categoryTag: String, authorName: String) {
        val post = SocialPostEntity(
            authorName = authorName,
            authorRole = "الحساب الرسمي للصيدلية",
            isOfficialPharmacy = true,
            title = title,
            content = content,
            categoryTag = categoryTag,
            likesCount = 0,
            commentsCount = 0,
            pinned = false,
            createdAt = System.currentTimeMillis()
        )
        socialDao.insertPost(post)
    }

    suspend fun deleteSocialPost(post: SocialPostEntity) {
        socialDao.deletePost(post)
    }

    suspend fun toggleLikePost(postId: Long, currentLiked: Boolean) {
        val delta = if (currentLiked) -1 else 1
        socialDao.updatePostLike(postId, delta, !currentLiked)
    }

    suspend fun addComment(
        productId: Long?,
        postId: Long?,
        userName: String,
        userRole: String,
        text: String,
        rating: Int,
        isVerified: Boolean
    ): Long {
        val comment = CommentEntity(
            productId = productId,
            postId = postId,
            userName = userName,
            userRole = userRole,
            commentText = text,
            rating = rating,
            isVerifiedPurchase = isVerified,
            likesCount = 0,
            createdAt = System.currentTimeMillis()
        )
        return socialDao.insertComment(comment)
    }

    suspend fun replyToComment(commentId: Long, replyText: String, replyBy: String) {
        socialDao.replyToComment(commentId, replyText, replyBy, System.currentTimeMillis())
    }

    suspend fun hideComment(commentId: Long, hidden: Boolean) {
        socialDao.setCommentHidden(commentId, hidden)
    }

    suspend fun reportComment(commentId: Long) {
        socialDao.reportComment(commentId)
    }

    suspend fun deleteComment(commentId: Long) {
        socialDao.deleteComment(commentId)
    }

    suspend fun submitMedicineRequest(medicineName: String, customerName: String, customerPhone: String, notes: String): Long {
        val req = MedicineRequestEntity(
            medicineName = medicineName,
            customerName = customerName,
            customerPhone = customerPhone,
            notes = notes,
            requestCount = 1,
            status = "PENDING",
            requestedAt = System.currentTimeMillis()
        )
        return extraDao.insertMedicineRequest(req)
    }

    suspend fun updateMedicineRequestStatus(requestId: Long, status: String) {
        val fulfilledAt = if (status == "ARRIVED") System.currentTimeMillis() else null
        extraDao.updateMedicineRequestStatus(requestId, status, fulfilledAt)
    }

    suspend fun updateSettings(settings: PharmacySettingsEntity, operator: String) {
        extraDao.updateSettings(settings)
        extraDao.insertAuditLog(
            AuditLogEntity(
                actionType = "SETTINGS_CHANGED",
                performedBy = operator,
                details = "تحديث بيانات وإعدادات الصيدلية وساعات العمل ورسوم التوصيل"
            )
        )
    }

    suspend fun validateCoupon(code: String): CouponEntity? {
        return extraDao.getCouponByCode(code.trim().uppercase(Locale.ROOT))
    }

    companion object {
        fun formatIqd(amount: Long): String {
            val formatter = NumberFormat.getNumberInstance(Locale.US)
            return "${formatter.format(amount)} د.ع"
        }
    }
}
