package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nameAr: String,
    val nameEn: String,
    val genericName: String,
    val activeIngredient: String,
    val strength: String,
    val dosageForm: String, // أقراص, شراب, كبسولات, مرهم, بخاخ, قطرة, حقن, أكياس
    val manufacturer: String,
    val categoryId: String,
    val priceIqd: Long,
    val originalPriceIqd: Long = 0,
    val costPriceIqd: Long = 0, // لحساب صافي الأرباح
    val discountPercent: Int = 0,
    val stockQuantity: Int,
    val minStockAlert: Int = 5,
    val batchNumber: String = "BCH-2026",
    val expiryDate: String = "2027-12",
    val isAvailable: Boolean = true,
    val requiresPrescription: Boolean = false,
    val descriptionAr: String,
    val usageInstructions: String,
    val warnings: String,
    val iconKey: String = "medicine",
    val isFeatured: Boolean = false,
    val isBestSeller: Boolean = false,
    val salesCount: Int = 0,
    val rating: Float = 5.0f,
    val ratingCount: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val iconKey: String,
    val descriptionAr: String,
    val displayOrder: Int = 0
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey
    val id: String, // e.g. ALH-1042
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val governorate: String, // بغداد, أربيل, البصرة, النجف...
    val deliveryType: String, // "DELIVERY" or "PICKUP"
    val status: String, // "NEW", "AWAITING_CONFIRMATION", "PREPARING", "OUT_FOR_DELIVERY", "COMPLETED", "CANCELLED"
    val subtotalIqd: Long,
    val discountIqd: Long = 0,
    val deliveryFeeIqd: Long = 3000,
    val totalIqd: Long,
    val paymentMethod: String = "CASH_ON_DELIVERY",
    val notes: String = "",
    val itemsSummary: String = "", // الملخص النصي للأصناف والكميات
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "order_items")
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderId: String,
    val productId: Long,
    val productNameAr: String,
    val unitPriceIqd: Long,
    val quantity: Int,
    val totalPriceIqd: Long
)

@Entity(tableName = "social_posts")
data class SocialPostEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val authorName: String = "صيدلية الحود الذكية",
    val authorRole: String = "الحساب الرسمي",
    val isOfficialPharmacy: Boolean = true,
    val title: String,
    val content: String,
    val categoryTag: String, // "نصيحة طبية", "عرض ترويجي", "صحة الأسرة", "توعية دوائية"
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val pinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long? = null,
    val postId: Long? = null,
    val userName: String,
    val userRole: String = "CUSTOMER", // "CUSTOMER", "PHARMACIST", "OWNER"
    val commentText: String,
    val rating: Int = 5,
    val isVerifiedPurchase: Boolean = false,
    val replyText: String? = null,
    val replyBy: String? = null,
    val replyTimestamp: Long? = null,
    val isReported: Boolean = false,
    val isHidden: Boolean = false,
    val likesCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "medicine_requests")
data class MedicineRequestEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val medicineName: String,
    val customerName: String,
    val customerPhone: String,
    val notes: String = "",
    val requestCount: Int = 1,
    val status: String = "PENDING", // "PENDING", "ARRIVED", "REJECTED"
    val requestedAt: Long = System.currentTimeMillis(),
    val fulfilledAt: Long? = null
)

@Entity(tableName = "coupons")
data class CouponEntity(
    @PrimaryKey
    val code: String,
    val discountPercent: Int,
    val minOrderIqd: Long = 0,
    val maxDiscountIqd: Long = 15000,
    val isActive: Boolean = true,
    val expiryDate: String = "2026-12-31"
)

@Entity(tableName = "pharmacy_settings")
data class PharmacySettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val pharmacyNameAr: String = "صيدلية الحود الذكية",
    val pharmacyNameEn: String = "Al-Houd Smart Pharmacy",
    val slogan: String = "رعايتكم الصحية أمانتنا • بغداد",
    val ownerName: String = "د. أحمد الحود (صيدلي ممارس)",
    val phoneNumber: String = "+964 770 123 4567",
    val whatsappNumber: String = "+964 780 123 4567",
    val address: String = "العراق - بغداد - المنصور - شارع 14 رمضان",
    val workingHours: String = "يومياً: 8:00 صباحاً - 12:00 منتصف الليل",
    val deliveryFeeIqd: Long = 3000,
    val freeDeliveryThresholdIqd: Long = 35000,
    val minOrderAmountIqd: Long = 5000,
    val pointsPerThousandIqd: Int = 1,
    val iqdPerPointRedeemed: Int = 50,
    val adminPin: String = "1234"
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val actionType: String, // "PRICE_UPDATE", "STOCK_UPDATE", "ORDER_STATUS", "PRODUCT_ADDED", "SETTINGS_CHANGED"
    val performedBy: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CartItem(
    val product: ProductEntity,
    val quantity: Int
)

enum class UserRole(val titleAr: String) {
    CUSTOMER("زبون"),
    PHARMACIST("صيدلي مناوب"),
    OWNER("صاحب الصيدلية / المدير")
}
