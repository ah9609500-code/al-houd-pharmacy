package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserRole
import com.example.ui.PharmacyViewModel
import com.example.ui.screens.*
import com.example.ui.theme.AlHoudPharmacyTheme
import com.example.ui.theme.PharmacyBadgeGreen
import com.example.ui.theme.PharmacyPrimary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AlHoudPharmacyTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PharmacyApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyApp(viewModel: PharmacyViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val cartItemCount by viewModel.cartItemCount.collectAsStateWithLifecycle()
    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val userRole by viewModel.userRole.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // Hardware and gesture Back Handler
    BackHandler(enabled = currentScreen != "home") {
        viewModel.navigateBack()
    }

    val isTopLevelScreen = currentScreen in listOf("home", "categories", "community", "orders", "account")

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (isTopLevelScreen) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_alhoud_logo),
                                    contentDescription = "شعار صيدلية الحود",
                                    modifier = Modifier.size(32.dp).clip(CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "صيدلية الحود الذكية",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(PharmacyBadgeGreen)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "مفتوح الآن • خدمة توصيل لكافة مناطق بغداد",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        // Shopping Cart Icon with Badge
                        IconButton(
                            onClick = { viewModel.navigateTo("cart") },
                            modifier = Modifier.testTag("top_bar_cart_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (cartItemCount > 0) {
                                        Badge(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = Color.White
                                        ) {
                                            Text("$cartItemCount")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ShoppingCart,
                                    contentDescription = "سلة التسوق",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Owner quick badge
                        if (userRole == UserRole.OWNER) {
                            IconButton(onClick = { viewModel.navigateTo("admin_dashboard") }) {
                                Icon(
                                    imageVector = Icons.Filled.AdminPanelSettings,
                                    contentDescription = "لوحة الإدارة",
                                    tint = PharmacyPrimary
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            if (isTopLevelScreen) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen == "home",
                        onClick = { viewModel.navigateTo("home") },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "home") Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "الرئيسية"
                            )
                        },
                        label = { Text("الرئيسية", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen == "categories",
                        onClick = { viewModel.navigateTo("categories") },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "categories") Icons.Filled.Category else Icons.Outlined.Category,
                                contentDescription = "الأقسام"
                            )
                        },
                        label = { Text("الأقسام", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_categories")
                    )

                    NavigationBarItem(
                        selected = currentScreen == "community",
                        onClick = { viewModel.navigateTo("community") },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "community") Icons.Filled.Groups else Icons.Outlined.Groups,
                                contentDescription = "المجتمع"
                            )
                        },
                        label = { Text("المجتمع", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_community")
                    )

                    NavigationBarItem(
                        selected = currentScreen == "orders",
                        onClick = { viewModel.navigateTo("orders") },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "orders") Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong,
                                contentDescription = "الطلبات"
                            )
                        },
                        label = { Text("الطلبات", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_orders")
                    )

                    NavigationBarItem(
                        selected = currentScreen == "account",
                        onClick = { viewModel.navigateTo("account") },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "account") Icons.Filled.Person else Icons.Outlined.Person,
                                contentDescription = "حسابي"
                            )
                        },
                        label = { Text("حسابي", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_account")
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "home" -> HomeScreen(viewModel = viewModel)
                "categories" -> CategoriesScreen(viewModel = viewModel)
                "community" -> CommunityScreen(viewModel = viewModel)
                "orders" -> OrdersScreen(viewModel = viewModel)
                "account" -> AccountScreen(viewModel = viewModel)
                "cart" -> CartAndCheckoutScreen(viewModel = viewModel)
                "admin_dashboard" -> AdminDashboardScreen(viewModel = viewModel)
                "medicine_request" -> MedicineRequestScreen(viewModel = viewModel)
                "compare" -> CompareScreen(viewModel = viewModel)
                "product_detail" -> {
                    selectedProduct?.let { product ->
                        ProductDetailScreen(product = product, viewModel = viewModel)
                    } ?: run {
                        HomeScreen(viewModel = viewModel)
                    }
                }
                else -> HomeScreen(viewModel = viewModel)
            }
        }
    }
}
